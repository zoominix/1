// order-ajax.js

document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".orders-tabs .tab");
    const highlight = document.querySelector(".orders-tabs .tab-highlight");
    const search = document.getElementById("order-search-input");
    const list = document.getElementById("orders-list");
    if (!list) return;
    const loading = document.getElementById("orders-loading");
    const loadMoreBtn = document.getElementById("orders-load-more");
    const emptyBox = document.getElementById("orders-empty");
    const emptyMsg = document.getElementById("orders-empty-message");

    let currentStatus = "all";
    let currentPage = 1;
    let searchValue = "";
    let hasMore = true;
    let currentFetchController = null;

    function moveHighlightTo(tab) {
        if (!highlight || !tab) return;

        const newWidth = tab.offsetWidth;
        const newLeft = tab.offsetLeft;

        highlight.style.transition = "all 0.3s ease";
        highlight.style.width = `${newWidth}px`;
        highlight.style.transform = `translateX(${newLeft}px)`;
    }

    function getSkeleton(count = 3) {
        let skeleton = "";
        for (let i = 0; i < count; i++) {
            skeleton += `<div class="order-card skeleton">
                <div class="order-header">
                    <div class="skeleton-box" style="width: 150px; height: 16px;"></div>
                    <div class="skeleton-box" style="width: 80px; height: 16px;"></div>
                </div>
                <div class="order-products">
                    <div class="order-product">
                        <div class="skeleton-img"></div>
                        <div class="product-info">
                            <div class="skeleton-box" style="width: 120px; height: 14px;"></div>
                            <div class="skeleton-box" style="width: 80px; height: 12px;"></div>
                        </div>
                    </div>
                </div>
            </div>`;
        }
        return skeleton;
    }

    function fetchOrders({ status = currentStatus, page = 1, search = searchValue, append = false }) {
        if (currentFetchController) {
            currentFetchController.abort();
        }
        currentFetchController = new AbortController();
        const signal = currentFetchController.signal;

        if (!append) {
            list.innerHTML = getSkeleton(3);
            if (loadMoreBtn) loadMoreBtn.style.display = "none";
        }
        if (emptyBox) emptyBox.style.display = "none";

        const data = new FormData();
        data.append("action", "zoominix_get_orders");
        data.append("status", status);
        data.append("search", search);
        data.append("offset", (page - 1) * 5);

        fetch(ajaxurl, {
            method: "POST",
            body: data,
            signal
        })
        .then(res => res.json())
        .then(res => {
            const nothingFoundBySearch = search.trim().length > 0;

            if (res.success && res.data.data && res.data.data.trim()) {
                if (append) {
                    list.insertAdjacentHTML("beforeend", res.data.data);
                } else {
                    list.innerHTML = res.data.data;
                }
                hasMore = res.data.has_more;
                if (loadMoreBtn) loadMoreBtn.style.display = hasMore ? "block" : "none";
            } else {
                if (!append) {
                    list.innerHTML = "";
                    if (nothingFoundBySearch) {
                        emptyMsg.textContent = "سفارشی با این مشخصات پیدا نشد.";
                    } else {
                        const statusTextMap = {
                            "all": "سفارش جدیدی ندارید.",
                            "completed": "سفارشات تکمیل‌شده‌ای ندارید.",
                            "cancelled": "سفارشات لغو شده‌ای ندارید.",
                            "processing": "سفارشی در حال انجام ندارید.",
                            "pending": "سفارشی در انتظار بررسی ندارید."
                        };
                        emptyMsg.textContent = statusTextMap[status] || "سفارشی یافت نشد.";
                    }
                    if (emptyBox) emptyBox.style.display = "block";
                }
                if (loadMoreBtn) loadMoreBtn.style.display = "none";
            }

            if (loading) loading.style.display = "none";
        })
        .catch(err => {
            if (err.name !== "AbortError") console.error(err);
        });
    }

    const debouncedSearch = debounce(() => {
        searchValue = search.value.trim();
        currentPage = 1;
        fetchOrders({ status: currentStatus, page: currentPage });
    }, 400);

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            moveHighlightTo(tab);
            currentStatus = tab.dataset.status;
            currentPage = 1;
            fetchOrders({ status: currentStatus, page: currentPage });
        });
    });

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener("click", () => {
            currentPage++;
            fetchOrders({ status: currentStatus, page: currentPage, append: true });
        });
    }

    if (search) search.addEventListener("input", debouncedSearch);

    const active = document.querySelector(".orders-tabs .tab.active");
    if (active) moveHighlightTo(active);

    fetchOrders({});

    window.addEventListener("resize", () => {
        const active = document.querySelector(".orders-tabs .tab.active");
        if (active) moveHighlightTo(active);
    });

    function debounce(func, delay) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), delay);
        };
    }
});
