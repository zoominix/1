<?php
// امنیت
defined('ABSPATH') || exit;

/**
 *  دریافت لیست علاقه‌مندی‌ها از user_meta
 */
add_action('wp_ajax_zoominix_get_wishlist', 'zoominix_get_wishlist_ajax');
function zoominix_get_wishlist_ajax() {
    if (!is_user_logged_in() || !check_ajax_referer('zoominix_wishlist_nonce', 'nonce', false)) {
        wp_send_json_error('Unauthorized');
    }

    $user_id = get_current_user_id();
    $meta = get_user_meta($user_id, 'zoominix_wishlist', true);
    $now = time();
    $valid = [];

    if (is_array($meta)) {
        foreach ($meta as $item) {
            if (
                isset($item['product_id'], $item['timestamp']) &&
                ($now - intval($item['timestamp'])) < 30 * DAY_IN_SECONDS
            ) {
                $valid[] = intval($item['product_id']);
            }
        }
    }

    wp_send_json_success(['wishlist' => $valid]);
}

/**
 *  ذخیره کل لیست (مثلاً بعد از لاگین)
 */
add_action('wp_ajax_zoominix_sync_wishlist', 'zoominix_sync_wishlist_ajax');
function zoominix_sync_wishlist_ajax() {
    if (!is_user_logged_in() || !check_ajax_referer('zoominix_wishlist_nonce', 'nonce', false)) {
        wp_send_json_error('Unauthorized');
    }

    $user_id = get_current_user_id();
    $wishlist = isset($_POST['wishlist']) ? json_decode(stripslashes($_POST['wishlist']), true) : [];
    if (!is_array($wishlist)) $wishlist = [];

    $new_data = array_map(function ($pid) {
        return [
            'product_id' => intval($pid),
            'timestamp' => time()
        ];
    }, array_unique($wishlist));

    update_user_meta($user_id, 'zoominix_wishlist', $new_data);
    wp_send_json_success(['wishlist' => wp_list_pluck($new_data, 'product_id')]);
}

/**
 *  حذف یک آیتم از wishlist کاربر (بهینه)
 */
add_action('wp_ajax_zoominix_remove_from_wishlist', 'zoominix_remove_from_wishlist_ajax');
function zoominix_remove_from_wishlist_ajax() {
    if (!is_user_logged_in() || !check_ajax_referer('zoominix_wishlist_nonce', 'nonce', false)) {
        wp_send_json_error('Unauthorized');
    }

    $user_id = get_current_user_id();
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    if (!$product_id) {
        wp_send_json_error('Invalid product');
    }

    $wishlist = get_user_meta($user_id, 'zoominix_wishlist', true);
    if (!is_array($wishlist)) $wishlist = [];

    // فیلتر کردن لیست بدون آیتم مشخص
    $updated = array_filter($wishlist, function ($item) use ($product_id) {
        return isset($item['product_id']) && intval($item['product_id']) !== $product_id;
    });

    update_user_meta($user_id, 'zoominix_wishlist', $updated);
    wp_send_json_success(['message' => 'Item removed']);
}
