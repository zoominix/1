document.addEventListener('DOMContentLoaded', function () {
  const filled = window.profileFilled || 0;
  const fillEl = document.querySelector('.progress-bar-fill');
  const marker = document.querySelector('.progress-marker');

  if (fillEl && marker) {
    fillEl.style.width = filled + '%';
    marker.style.right = filled + '%';
    marker.innerText = filled + '%';
  }
});
