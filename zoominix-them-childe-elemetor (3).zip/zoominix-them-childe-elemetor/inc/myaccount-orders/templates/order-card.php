<?php
defined('ABSPATH') || exit;
$order_id = $order->get_id();
$status = wc_get_order_status_name($order->get_status());
$date = $order->get_date_created()->date('Y-m-d');
?>
<div class="order-card" data-status="<?php echo esc_attr($order->get_status()); ?>" data-order-id="<?php echo $order_id; ?>">
    <div class="order-header">
        <div class="hed-order">
            <strong>سفارش #<?php echo $order_id; ?></strong>
            <span><?php echo $status; ?></span>
            <small><?php echo $date; ?></small>
        </div>
        <a href="<?php echo esc_url($order->get_view_order_url()); ?>" class="view-order">مشاهده سفارش</a>
    </div>

    <div class="order-products">
        <?php foreach ($order->get_items() as $item): 
            $product = $item->get_product();
            if (!$product) continue;
        ?>
            <div class="order-product">
                <img src="<?php echo get_the_post_thumbnail_url($product->get_id(), 'woocommerce_thumbnail'); ?>" alt="">
                <div class="product-info">
                    <p><?php echo $item->get_name(); ?></p>
                    <span class="stock-status"><?php echo $product->is_in_stock() ? 'موجود' : 'ناموجود'; ?></span>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
