<?php
// جلوگیری از دسترسی مستقیم
defined('ABSPATH') || exit;
/**
 * شورتکد نمایش ۴ ویژگی اول محصول
 * استفاده: [first_four_attributes]
 */
add_shortcode('first_four_attributes', 'display_first_four_attributes');
function display_first_four_attributes() {
    global $product;
    if (!$product instanceof WC_Product) {
        $product = wc_get_product(get_the_ID());
    }
    if (!$product) return '';
    $product_id = $product->get_id();
    $cache_key = 'first_four_attributes_' . $product_id;
    $cached_output = get_transient($cache_key);
    if ($cached_output !== false) {
        return $cached_output;
    }
    $attributes = $product->get_attributes();
    if (empty($attributes)) return '';
    $output = '<div class="product-attributes">';
    $output .= '<h6>ویژگی‌های محصول</h6>';
    $output .= '<ul>';
    $count = 0;
    foreach ($attributes as $attribute) {
        if ($attribute->get_variation()) continue;

        $name = wc_attribute_label($attribute->get_name());
        $value = $attribute->is_taxonomy()
            ? implode(', ', wc_get_product_terms($product_id, $attribute->get_name(), ['fields' => 'names']))
            : implode(', ', $attribute->get_options());

        if ($count < 4) {
            $output .= '<li class="attribiute-lise"><h6><strong>' . esc_html($name) . '</strong> ' . esc_html($value) . '</h6></li>';
        }
        $count++;
        if ($count >= 4) break;
    }
    $output .= '</ul>';
    $output .= '</div>';

    $output .= '<section class="btn-attribute">';
    $output .= '<a href="javascript:void(0);" class="button-attributee" data-product-id="' . esc_attr($product_id) . '">مشاهده همه ویژگی ها</a>';
    $output .= '</section>';

    set_transient($cache_key, $output, 150 * HOUR_IN_SECONDS);

    return $output;
}
add_action('save_post_product', 'clear_first_four_attributes_cache');
function clear_first_four_attributes_cache($post_id) {
    delete_transient('first_four_attributes_' . $post_id);
}