document.addEventListener('DOMContentLoaded', () => {
  const storageKey = 'zoominix_wishlist';
  const isLoggedIn = document.body.classList.contains('logged-in');
  const buttons = document.querySelectorAll('.zoominix-wishlist-btn');
  let debounceTimer;

  function getProductId(button) {
    let id = parseInt(button.dataset.productId);
    if ((!id || isNaN(id)) && typeof zoominix_product_id !== 'undefined') {
      id = parseInt(zoominix_product_id);
    }
    return id;
  }

  function getWishlist() {
    try {
      const raw = localStorage.getItem(storageKey);
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed?.items) ? parsed.items : [];
    } catch {
      return [];
    }
  }

  function saveWishlist(items) {
    const data = {
      items,
      timestamp: new Date().getTime()
    };
    localStorage.setItem(storageKey, JSON.stringify(data));

    if (isLoggedIn && typeof zoominixWishlist !== 'undefined') {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        fetch(zoominixWishlist.ajaxurl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            action: 'zoominix_sync_wishlist',
            nonce: zoominixWishlist.nonce,
            wishlist: JSON.stringify(items)
          })
        });
      }, 1000);
    }

    // اطلاع‌رسانی به تب‌های دیگر
    localStorage.setItem('__wishlist_updated', new Date().getTime());
  }

  function updateButtonUI(button, isActive) {
    button.classList.toggle('filled', isActive);
  }

  function showToast(message) {
    const toast = document.getElementById('wishlist-toast');
    if (!toast) return;
    toast.textContent = message;
    toast.style.display = 'block';
    setTimeout(() => {
      toast.style.display = 'none';
    }, 2000);
  }

  function toggleWishlistItem(button) {
    const productId = getProductId(button);
    if (!productId) return;

    let wishlist = getWishlist();
    const isInList = wishlist.includes(productId);

    if (isInList) {
      wishlist = wishlist.filter(id => id !== productId);
      updateButtonUI(button, false);
      showToast('❌ از علاقه‌مندی‌ها حذف شد');
    } else {
      wishlist.push(productId);
      updateButtonUI(button, true);
      showToast('✅ به علاقه‌مندی‌ها اضافه شد');
    }

    saveWishlist(wishlist);
  }

  // Initial حالت filled
  const currentWishlist = getWishlist();
  buttons.forEach(button => {
    const id = getProductId(button);
    if (!id || isNaN(id)) return;
    if (currentWishlist.includes(id)) {
      updateButtonUI(button, true);
    }

    // Bind click
    button.addEventListener('click', e => {
      e.preventDefault();
      toggleWishlistItem(button);
    });
  });
});
