<?php
defined('ABSPATH') || exit;

/**
 * بارگذاری استایل‌ها و اسکریپت‌ها به‌صورت متمرکز
 */
add_action('wp_enqueue_scripts', 'zoominix_enqueue_assets');

function zoominix_enqueue_assets() {

    // سبد خرید
    if (function_exists('is_cart') && is_cart()) {
        wp_enqueue_style('zoominix-cart-style', get_stylesheet_directory_uri() . '/assets/css/cart.css', [], '1.0');
    }

    // تسویه حساب
    if (function_exists('is_checkout') && is_checkout()) {
        wp_enqueue_style('zoominix-checkout-style', get_stylesheet_directory_uri() . '/assets/css/checkout-custom.css', [], '1.0');
    }

    // حساب کاربری
    if (is_account_page()) {
        wp_enqueue_script('zoominix-dashboard-chart', get_stylesheet_directory_uri() . '/assets/js/dashboard-chart.js', ['jquery'], '1.0', true);
        wp_enqueue_style('zoominix-dashboard-style', get_stylesheet_directory_uri() . '/assets/css/dashboard-custome.css', [], '1.0');
        wp_enqueue_style('zoominix-orders-style', get_stylesheet_directory_uri() . '/assets/css/dashboard-orders.css');
        wp_enqueue_script('zoominix-orders-script', get_stylesheet_directory_uri() . '/inc/myaccount-orders/js/orders-ajax.js', ['jquery'], null, true);
        wp_localize_script('zoominix-orders-script', 'ajaxurl', admin_url('admin-ajax.php'));
    }

    // صفحات محصول، فروشگاه، علاقه‌مندی‌ها
    if (is_product() || is_shop() || is_product_category() || is_product_tag() || is_page('wishlistpage')) {
        wp_enqueue_style('zoominix-qty-style', get_stylesheet_directory_uri() . '/assets/css/qty-style.css', [], '2.0');
        wp_enqueue_script('zoominix-qty-js', get_stylesheet_directory_uri() . '/assets/js/qty-buttons.js', ['jquery'], '1.5', true);
    }

    // مینی‌کارت در همه صفحات
    wp_enqueue_style('mini-cart-style', get_stylesheet_directory_uri() . '/assets/css/mini-cart-style.css', [], '1.0');
}
