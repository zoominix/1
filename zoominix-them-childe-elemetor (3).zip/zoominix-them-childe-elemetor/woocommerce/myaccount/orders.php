<?php defined('ABSPATH') || exit; ?>

<div class="my-orders-wrapper">
    <section class="hed-order">
        <div class="orders-tabs">
            <div class="tab-highlight"></div>
            <button class="tab active" data-status="all">همه سفارشات</button>
            <button class="tab" data-status="completed">تکمیل شده</button>
            <button class="tab" data-status="cancelled">لغو شده</button>
            <button class="tab" data-status="processing">در حال انجام</button>
            <button class="tab" data-status="on-hold">در حال بررسی</button>
        </div>

        <div class="order-search">
            <input type="text" id="order-search-input" placeholder="جستجو سفارش...">
        </div>
    </section>

    <div id="orders-loading" class="orders-loading" style="display: none;">
        <div class="spinner"></div>
    </div>

    <div id="orders-list" class="orders-list">
        <?php for ($i = 0; $i < 3; $i++): ?>
            <div class="order-card skeleton">
                <div class="order-header">
                    <div class="skeleton-box" style="width: 120px; height: 16px;"></div>
                    <div class="skeleton-box" style="width: 60px; height: 16px;"></div>
                    <div class="skeleton-box" style="width: 80px; height: 14px;"></div>
                    <div class="skeleton-box" style="width: 100px; height: 26px;"></div>
                </div>
                <div class="order-products">
                    <?php for ($j = 0; $j < 2; $j++): ?>
                        <div class="order-product">
                            <div class="skeleton-box" style="width: 60px; height: 60px; border-radius: 6px;"></div>
                            <div class="product-info">
                                <div class="skeleton-box" style="width: 150px; height: 14px;"></div>
                                <div class="skeleton-box" style="width: 80px; height: 13px; margin-top: 6px;"></div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        <?php endfor; ?>
    </div>

    <div id="orders-empty" class="orders-empty" style="display: none;">
        <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/icon/empty-order.webp" alt="سفارشی نیست" width="120" height="120" loading="lazy">
        <p id="orders-empty-message">سفارشی یافت نشد</p>
    </div>
    <div class="orders-load-more-wrapper" style="display: none;">
        <button id="orders-load-more" class="orders-load-more-btn">نمایش سفارشات بیشتر</button>
    </div>
</div>
