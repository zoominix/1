/**
 * Ultimate Final Currency Manager for WooCommerce Toman Icon
 * حل نهایی و کامل تمام مشکلات نمایش نماد تومان در ووکامرس
 * شامل رفع مشکل انتخابگرهای WooCommerce Blocks در صفحه تسویه حساب
 * 
 * @version 2.4.0
 * @author Manus AI
 * @description حل کامل مشکلات موقعیت نماد و نمایش در تمام صفحات و عناصر
 */

class UltimateFinalCurrencyManager {
    constructor() {
        this.config = {
            tokenPattern: '[TOMAN_ICON]',
            iconClass: 'custom-currency-icon',
            processedAttribute: 'data-currency-processed',
            positionAttribute: 'data-currency-position',
            hiddenClass: 'currency-hidden',
            readyClass: 'currency-ready',
            debugMode: false
        };
        
        this.cache = new Map();
        this.observers = new Set();
        this.isInitialized = false;
        this.currencyPosition = 'right';
        this.processingQueue = [];
        this.isProcessing = false;
        this.debounceTimer = null;
        this.forceInlineStyles = true;
        
        // Bind methods
        this.handleMutations = this.handleMutations.bind(this);
        this.processQueue = this.processQueue.bind(this);
        this.debouncedProcessing = this.debouncedProcessing.bind(this);
        
        // فوری‌ترین جلوگیری از FOUC
        this.immediatePreventFOUC();
    }
    
    /**
     * جلوگیری فوری از FOUC قبل از هر چیز
     */
    immediatePreventFOUC() {
        const style = document.createElement('style');
        style.id = 'ultimate-final-fouc-prevention';
        style.textContent = `
            /* مخفی‌سازی فوری توکن در تمام عناصر ممکن */
            .woocommerce-Price-amount:not([data-currency-processed]),
            .wc-block-formatted-money-amount:not([data-currency-processed]),
            .wc-block-components-formatted-money-amount:not([data-currency-processed]),
            .wc-block-components-product-price:not([data-currency-processed]),
            .wc-block-components-product-price__value:not([data-currency-processed]),
            .wc-block-components-product-price__regular:not([data-currency-processed]),
            .wc-block-components-product-price__sale:not([data-currency-processed]),
            .wc-block-cart-item__price:not([data-currency-processed]),
            .wc-block-components-order-summary-item__price:not([data-currency-processed]) {
                visibility: hidden !important;
                position: relative !important;
            }
            
            .woocommerce-Price-amount:not([data-currency-processed])::after,
            .wc-block-formatted-money-amount:not([data-currency-processed])::after,
            .wc-block-components-formatted-money-amount:not([data-currency-processed])::after,
            .wc-block-components-product-price:not([data-currency-processed])::after,
            .wc-block-components-product-price__value:not([data-currency-processed])::after,
            .wc-block-components-product-price__regular:not([data-currency-processed])::after,
            .wc-block-components-product-price__sale:not([data-currency-processed])::after,
            .wc-block-cart-item__price:not([data-currency-processed])::after,
            .wc-block-components-order-summary-item__price:not([data-currency-processed])::after {
                content: "..." !important;
                visibility: visible !important;
                position: absolute !important;
                top: 50% !important;
                left: 50% !important;
                transform: translate(-50%, -50%) !important;
                font-size: 12px !important;
                color: #999 !important;
                z-index: 1 !important;
            }
            
            /* نمایش فوری پس از پردازش */
            .woocommerce-Price-amount[data-currency-processed],
            .wc-block-formatted-money-amount[data-currency-processed],
            .wc-block-components-formatted-money-amount[data-currency-processed],
            .wc-block-components-product-price[data-currency-processed],
            .wc-block-components-product-price__value[data-currency-processed],
            .wc-block-components-product-price__regular[data-currency-processed],
            .wc-block-components-product-price__sale[data-currency-processed],
            .wc-block-cart-item__price[data-currency-processed],
            .wc-block-components-order-summary-item__price[data-currency-processed] {
                visibility: visible !important;
                opacity: 1 !important;
            }
            
            .woocommerce-Price-amount[data-currency-processed]::after,
            .wc-block-formatted-money-amount[data-currency-processed]::after,
            .wc-block-components-formatted-money-amount[data-currency-processed]::after,
            .wc-block-components-product-price[data-currency-processed]::after,
            .wc-block-components-product-price__value[data-currency-processed]::after,
            .wc-block-components-product-price__regular[data-currency-processed]::after,
            .wc-block-components-product-price__sale[data-currency-processed]::after,
            .wc-block-cart-item__price[data-currency-processed]::after,
            .wc-block-components-order-summary-item__price[data-currency-processed]::after {
                display: none !important;
            }
        `;
        
        if (document.head) {
            document.head.appendChild(style);
        } else {
            document.addEventListener('DOMContentLoaded', () => {
                if (!document.getElementById('ultimate-final-fouc-prevention')) {
                    document.head.appendChild(style);
                }
            });
        }
    }
    
    /**
     * راه‌اندازی اولیه سیستم
     */
    async initialize() {
        if (this.isInitialized) return;
        
        try {
            this.log('🚀 Ultimate Final Currency Manager: شروع راه‌اندازی...');
            
            await this.setupInitialConfiguration();
            await this.preloadResources();
            this.setupAdvancedFOUCPrevention();
            this.setupObservers();
            this.processExistingElementsImmediately();
            this.setupReactIntegration();
            this.setupEventHandlers();
            this.setupContinuousMonitoring();
            this.setupFOUCFallback();
            
            this.isInitialized = true;
            this.log('✅ Ultimate Final Currency Manager: راه‌اندازی کامل شد');
            
        } catch (error) {
            console.error('❌ Ultimate Final Currency Manager: خطا در راه‌اندازی:', error);
        }
    }
    
    /**
     * تنظیمات اولیه
     */
    async setupInitialConfiguration() {
        this.currencyPosition = await this.detectCurrencyPositionAccurate();
        this.log('📍 موقعیت ارز تشخیص داده شد:', this.currencyPosition);
        
        this.setCSSVariables();
        
        document.body.classList.add('ultimate-final-currency-manager-active');
        document.body.setAttribute(this.config.positionAttribute, this.currencyPosition);
        
        if (typeof currencySettings !== 'undefined' && currencySettings.debug) {
            this.config.debugMode = true;
        }
    }
    
    /**
     * تشخیص دقیق موقعیت ارز
     */
    async detectCurrencyPositionAccurate() {
        // اولویت 1: تنظیمات مستقیم از currencySettings
        if (typeof currencySettings !== 'undefined' && currencySettings.currency_pos) {
            this.log('موقعیت از currencySettings:', currencySettings.currency_pos);
            return currencySettings.currency_pos;
        }
        
        // اولویت 2: متا تگ
        const metaTag = document.querySelector('meta[name="wc-currency-position"]');
        if (metaTag) {
            const position = metaTag.getAttribute('content');
            this.log('موقعیت از meta tag:', position);
            return position;
        }
        
        // اولویت 3: تنظیمات WooCommerce در صفحات خاص
        if (typeof wc_checkout_params !== 'undefined' && wc_checkout_params.currency_pos) {
            this.log('موقعیت از wc_checkout_params:', wc_checkout_params.currency_pos);
            return wc_checkout_params.currency_pos;
        }
        
        if (typeof woocommerce_params !== 'undefined' && woocommerce_params.currency_pos) {
            this.log('موقعیت از woocommerce_params:', woocommerce_params.currency_pos);
            return woocommerce_params.currency_pos;
        }
        
        // اولویت 4: درخواست AJAX
        try {
            const ajaxPosition = await this.fetchCurrencyPositionViaAjax();
            if (ajaxPosition) {
                this.log('موقعیت از AJAX:', ajaxPosition);
                return ajaxPosition;
            }
        } catch (error) {
            this.log('خطا در دریافت موقعیت از AJAX:', error);
        }
        
        // اولویت 5: پیش‌فرض
        const htmlLang = document.documentElement.lang || "";
        const isRTL = document.dir === "rtl" || 
                     document.documentElement.dir === "rtl" ||
                     htmlLang.startsWith("fa") || 
                     htmlLang.startsWith("ar") ||
                     htmlLang.startsWith("he");
        
        let defaultPosition = isRTL ? "left" : "right";

        // Fallback: Read from a sample element if available
        const sampleEl = document.querySelector(".woocommerce-Price-amount");
        if (sampleEl) {
            const computedStyle = window.getComputedStyle(sampleEl);
            if (computedStyle.flexDirection === "row") {
                defaultPosition = "left";
            } else if (computedStyle.flexDirection === "row-reverse") {
                defaultPosition = "right";
            }
        }

        this.log("موقعیت پیش‌فرض بر اساس RTL و fallback:", defaultPosition);
        return defaultPosition;
    }
    
    /**
     * درخواست AJAX برای دریافت موقعیت ارز
     */
    async fetchCurrencyPositionViaAjax() {
        return new Promise((resolve) => {
            if (typeof jQuery !== 'undefined' && typeof wc_add_to_cart_params !== 'undefined') {
                jQuery.ajax({
                    url: wc_add_to_cart_params.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'get_currency_position',
                        nonce: wc_add_to_cart_params.wc_ajax_nonce
                    },
                    success: function(response) {
                        if (response.success && response.data.currency_pos) {
                            resolve(response.data.currency_pos);
                        } else {
                            resolve(null);
                        }
                    },
                    error: function() {
                        resolve(null);
                    },
                    timeout: 2000
                });
            } else {
                resolve(null);
            }
        });
    }
    
    /**
     * تنظیم CSS Variables
     */
    setCSSVariables() {
        const root = document.documentElement;
        
        const flexDirection = this.currencyPosition.includes('left') ? 'row' : 'row-reverse';
        root.style.setProperty('--ultimate-currency-flex-direction', flexDirection);
        
        const gap = this.currencyPosition.includes('_space') ? '4px' : '2px';
        root.style.setProperty('--ultimate-currency-gap', gap);
        
        root.style.setProperty('--ultimate-currency-position', this.currencyPosition);
        
        const iconOrder = this.currencyPosition.includes('left') ? '-1' : '1';
        root.style.setProperty('--ultimate-currency-icon-order', iconOrder);
        
        this.log('CSS Variables تنظیم شد:', { flexDirection, gap, position: this.currencyPosition, iconOrder });
    }
    
    /**
     * پیش‌بارگذاری منابع
     */
    async preloadResources() {
        return new Promise((resolve) => {
        if (typeof currencySettings === 'undefined' || !currencySettings.svg_url || !currencySettings.svg_url.includes('.svg')) {
            window.currencySettings = {
                svg_url: '/wp-content/themes/YOUR_THEME_NAME/assets/icon/tooman.svg', // Replace YOUR_THEME_NAME with your actual theme name
                currency_pos: 'right',
                debug: false,
                token: '[TOMAN_ICON]'
            };
            this.log('currencySettings با مقادیر پیش‌فرض مقداردهی شد.');
        }

        if (typeof currencySettings !== 'undefined' && currencySettings.svg_url) {
            const link = document.createElement('link');
                link.rel = 'preload';
                link.href = currencySettings.svg_url;
                link.as = 'image';
                link.type = 'image/svg+xml';
                link.onload = () => {
                    this.log('SVG پیش‌بارگذاری شد');
                    resolve();
                };
                link.onerror = () => {
                    this.log('خطا در پیش‌بارگذاری SVG');
                    resolve();
                };
                document.head.appendChild(link);
            } else {
                resolve();
            }
        });
    }
    
    /**
     * راه‌اندازی پیشرفته جلوگیری از FOUC
     */
    setupAdvancedFOUCPrevention() {
        const existingStyle = document.getElementById('ultimate-final-fouc-prevention');
        if (existingStyle) {
            existingStyle.remove();
        }
        
        const style = document.createElement('style');
        style.id = 'ultimate-final-advanced-fouc-prevention';
        style.textContent = this.getAdvancedFOUCCSS();
        
        document.head.appendChild(style);
        this.log('Ultimate Final Advanced FOUC prevention تنظیم شد');
    }
    
    /**
     * دریافت CSS پیشرفته جلوگیری از FOUC
     */
    getAdvancedFOUCCSS() {
        const flexDirection = this.currencyPosition.includes('left') ? 'row' : 'row-reverse';
        const gap = this.currencyPosition.includes('_space') ? '4px' : '2px';
        const iconOrder = this.currencyPosition.includes('left') ? '-1' : '1';
        
        return `
            /* جلوگیری پیشرفته از FOUC برای تمام عناصر */
            .woocommerce-Price-amount:not([${this.config.processedAttribute}]),
            .wc-block-formatted-money-amount:not([${this.config.processedAttribute}]),
            .wc-block-components-formatted-money-amount:not([${this.config.processedAttribute}]),
            .wc-block-components-product-price:not([${this.config.processedAttribute}]),
            .wc-block-components-product-price__value:not([${this.config.processedAttribute}]),
            .wc-block-components-product-price__regular:not([${this.config.processedAttribute}]),
            .wc-block-components-product-price__sale:not([${this.config.processedAttribute}]),
            .wc-block-cart-item__price:not([${this.config.processedAttribute}]),
            .wc-block-components-order-summary-item__price:not([${this.config.processedAttribute}]),
            .wc-block-components-totals-item__value:not([${this.config.processedAttribute}]) {
                visibility: hidden !important;
                position: relative !important;
            }
            
            .woocommerce-Price-amount:not([${this.config.processedAttribute}])::before,
            .wc-block-formatted-money-amount:not([${this.config.processedAttribute}])::before,
            .wc-block-components-formatted-money-amount:not([${this.config.processedAttribute}])::before,
            .wc-block-components-product-price:not([${this.config.processedAttribute}])::before,
            .wc-block-components-product-price__value:not([${this.config.processedAttribute}])::before,
            .wc-block-components-product-price__regular:not([${this.config.processedAttribute}])::before,
            .wc-block-components-product-price__sale:not([${this.config.processedAttribute}])::before,
            .wc-block-cart-item__price:not([${this.config.processedAttribute}])::before,
            .wc-block-components-order-summary-item__price:not([${this.config.processedAttribute}])::before,
            .wc-block-components-totals-item__value:not([${this.config.processedAttribute}])::before {
                content: '' !important;
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                background: linear-gradient(90deg, 
                    rgba(200,200,200,0.3) 25%, 
                    rgba(200,200,200,0.1) 37%, 
                    rgba(200,200,200,0.3) 63%) !important;
                background-size: 400% 100% !important;
                animation: ultimate-shimmer 1.5s ease-in-out infinite !important;
                border-radius: 3px !important;
                visibility: visible !important;
                z-index: 1 !important;
            }
            
            @keyframes ultimate-shimmer {
                0% { background-position: 100% 0; }
                100% { background-position: -100% 0; }
            }
            
            /* نمایش نهایی */
            .woocommerce-Price-amount[${this.config.processedAttribute}],
            .wc-block-formatted-money-amount[${this.config.processedAttribute}],
            .wc-block-components-formatted-money-amount[${this.config.processedAttribute}],
            .wc-block-components-product-price[${this.config.processedAttribute}],
            .wc-block-components-product-price__value[${this.config.processedAttribute}],
            .wc-block-components-product-price__regular[${this.config.processedAttribute}],
            .wc-block-components-product-price__sale[${this.config.processedAttribute}],
            .wc-block-cart-item__price[${this.config.processedAttribute}],
            .wc-block-components-order-summary-item__price[${this.config.processedAttribute}],
            .wc-block-components-totals-item__value[${this.config.processedAttribute}] {
                visibility: visible !important;
                opacity: 1 !important;
                transition: opacity 0.2s ease-in-out !important;
            }
            
            .woocommerce-Price-amount[${this.config.processedAttribute}]::before,
            .wc-block-formatted-money-amount[${this.config.processedAttribute}]::before,
            .wc-block-components-formatted-money-amount[${this.config.processedAttribute}]::before,
            .wc-block-components-product-price[${this.config.processedAttribute}]::before,
            .wc-block-components-product-price__value[${this.config.processedAttribute}]::before,
            .wc-block-components-product-price__regular[${this.config.processedAttribute}]::before,
            .wc-block-components-product-price__sale[${this.config.processedAttribute}]::before,
            .wc-block-cart-item__price[${this.config.processedAttribute}]::before,
            .wc-block-components-order-summary-item__price[${this.config.processedAttribute}]::before,
            .wc-block-components-totals-item__value[${this.config.processedAttribute}]::before {
                display: none !important;
            }
            
            /* تنظیمات flexbox قوی */
            .woocommerce-Price-amount,
            .wc-block-formatted-money-amount,
            .wc-block-components-formatted-money-amount,
            .wc-block-components-product-price,
            .wc-block-components-product-price__value,
            .wc-block-components-product-price__regular,
            .wc-block-components-product-price__sale,
            .wc-block-cart-item__price,
            .wc-block-components-order-summary-item__price,
            .wc-block-components-totals-item__value {
                display: inline-flex !important;
                align-items: center !important;
                flex-direction: ${flexDirection} !important;
                gap: ${gap} !important;
            }
            
            /* اولویت بالا برای موقعیت‌ها */
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left"] .woocommerce-Price-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left_space"] .woocommerce-Price-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left"] .wc-block-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left_space"] .wc-block-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left"] .wc-block-components-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left_space"] .wc-block-components-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left"] .wc-block-components-product-price,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left_space"] .wc-block-components-product-price,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left"] .wc-block-components-product-price__value,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="left_space"] .wc-block-components-product-price__value {
                flex-direction: row !important;
            }
            
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right"] .woocommerce-Price-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right_space"] .woocommerce-Price-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right"] .wc-block-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right_space"] .wc-block-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right"] .wc-block-components-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right_space"] .wc-block-components-formatted-money-amount,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right"] .wc-block-components-product-price,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right_space"] .wc-block-components-product-price,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right"] .wc-block-components-product-price__value,
            .ultimate-final-currency-manager-active[${this.config.positionAttribute}="right_space"] .wc-block-components-product-price__value {
                flex-direction: row-reverse !important;
            }
            
            /* تنظیمات آیکن */
            .custom-currency-icon {
                order: ${iconOrder} !important;
                flex-shrink: 0 !important;
                display: inline-block !important;
                width: 1em !important;
                height: 1em !important;
                background-size: contain !important;
                background-repeat: no-repeat !important;
                background-position: center !important;
                vertical-align: middle !important;
            }
            
            /* CSS Variables */
            :root {
                --ultimate-currency-flex-direction: ${flexDirection};
                --ultimate-currency-gap: ${gap};
                --ultimate-currency-position: ${this.currencyPosition};
                --ultimate-currency-icon-order: ${iconOrder};
            }
        `;
    }
    
    /**
     * راه‌اندازی observers
     */
    setupObservers() {
        const mainObserver = new MutationObserver(this.debouncedProcessing);
        mainObserver.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true,
            attributes: false
        });
        this.observers.add(mainObserver);
        
        this.setupReactObservers();
        this.log('Observers راه‌اندازی شدند');
    }
    
    /**
     * پردازش با debouncing
     */
    debouncedProcessing(mutations) {
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        
        this.debounceTimer = setTimeout(() => {
            this.handleMutations(mutations);
        }, 30);
    }
    
    /**
     * راه‌اندازی observers ویژه React
     */
    setupReactObservers() {
        const reactSelectors = [
            '.wc-block-cart',
            '.wc-block-checkout',
            '.wc-block-mini-cart',
            '[data-block-name*="woocommerce"]',
            '.elementor-widget-woocommerce-menu-cart',
            '.woocommerce-checkout-review-order-table',
            '.woocommerce-cart-form',
            '.wc-block-cart-items',
            '.wc-block-checkout-order-summary'
        ];
        
        reactSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                const observer = new MutationObserver((mutations) => {
                    const relevantMutations = mutations.filter(mutation => 
                        mutation.type === 'childList' || mutation.type === 'characterData'
                    );
                    
                    if (relevantMutations.length > 0) {
                        this.log('React component تغییر کرد:', selector);
                        this.queueProcessing();
                    }
                });
                
                observer.observe(element, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });
                
                this.observers.add(observer);
            });
        });
    }
    
    /**
     * مدیریت mutations
     */
    handleMutations(mutations) {
        const relevantMutations = this.filterRelevantMutations(mutations);
        if (relevantMutations.length > 0) {
            this.log('Relevant mutations یافت شد:', relevantMutations.length);
            this.queueProcessing();
        }
    }
    
    /**
     * فیلتر mutations مرتبط
     */
    filterRelevantMutations(mutations) {
        return mutations.filter(mutation => {
            if (mutation.type === 'childList') {
                return Array.from(mutation.addedNodes).some(node => 
                    node.nodeType === Node.ELEMENT_NODE && 
                    this.isRelevantElement(node)
                );
            }
            
            if (mutation.type === 'characterData') {
                const parent = mutation.target.parentElement;
                return parent && this.isRelevantElement(parent);
            }
            
            return false;
        });
    }
    
    /**
     * بررسی مرتبط بودن عنصر
     */
    isRelevantElement(element) {
        if (!element.matches) return false;
        
        const relevantSelectors = [
            '.woocommerce-Price-amount',
            '.price',
            '.amount',
            '.wc-block-formatted-money-amount',
            '.wc-block-components-formatted-money-amount',
            '.wc-block-components-product-price',
            '.wc-block-components-product-price__value',
            '.wc-block-components-product-price__regular',
            '.wc-block-components-product-price__sale',
            '.wc-block-cart-item__price',
            '.wc-block-components-order-summary-item__price',
            '.wc-block-components-totals-item__value'
        ];
        
        return relevantSelectors.some(selector => 
            element.matches(selector) || element.querySelector(selector)
        ) || element.textContent.includes(this.config.tokenPattern);
    }
    
    /**
     * اضافه کردن به صف پردازش
     */
    queueProcessing() {
        if (!this.isProcessing) {
            this.isProcessing = true;
            requestAnimationFrame(this.processQueue);
        }
    }
    
    /**
     * پردازش صف
     */
    processQueue() {
        this.processNewElements();
        this.isProcessing = false;
    }
    
    /**
     * پردازش فوری عناصر موجود
     */
    processExistingElementsImmediately() {
        const elements = this.findAllPriceElements();
        this.log(`🔍 ${elements.length} عنصر قیمت یافت شد برای پردازش فوری`);
        
        elements.forEach(element => {
            this.processElement(element);
        });
        
        setTimeout(() => {
            const remainingElements = this.findAllPriceElements().filter(element => 
                !element.getAttribute(this.config.processedAttribute)
            );
            
            if (remainingElements.length > 0) {
                this.log(`🔄 ${remainingElements.length} عنصر باقی‌مانده پردازش می‌شود`);
                remainingElements.forEach(element => this.processElement(element));
            }
        }, 50);
        
        setTimeout(() => {
            const finalElements = this.findAllPriceElements().filter(element => 
                !element.getAttribute(this.config.processedAttribute)
            );
            
            if (finalElements.length > 0) {
                this.log(`🔄 ${finalElements.length} عنصر نهایی پردازش می‌شود`);
                finalElements.forEach(element => this.processElement(element));
            }
        }, 200);
    }
    
    /**
     * پردازش عناصر جدید
     */
    processNewElements() {
        const elements = this.findAllPriceElements().filter(element => 
            !element.getAttribute(this.config.processedAttribute)
        );
        
        if (elements.length > 0) {
            this.log(`🆕 ${elements.length} عنصر جدید پردازش می‌شود`);
            elements.forEach(element => this.processElement(element));
        }
    }
    
    /**
     * یافتن تمام عناصر قیمت - شامل انتخابگرهای جدید WooCommerce Blocks
     */
    findAllPriceElements() {
        const selectors = [
            // انتخابگرهای کلاسیک
            '.woocommerce-Price-amount',
            '.price .woocommerce-Price-amount',
            '.amount',
            
            // انتخابگرهای WooCommerce Blocks
            '.wc-block-formatted-money-amount',
            '.wc-block-components-formatted-money-amount',
            '.wc-block-components-product-price',
            '.wc-block-components-product-price__value',
            '.wc-block-components-product-price__regular',
            '.wc-block-components-product-price__sale',
            '.wc-block-cart-item__price',
            '.wc-block-components-order-summary-item__price',
            '.wc-block-components-totals-item__value',
            
            // انتخابگرهای ویژه صفحات
            '.wc-block-cart-item__price .wc-block-formatted-money-amount',
            '.wc-block-components-product-price .wc-block-formatted-money-amount',
            '.wc-block-checkout-order-summary__item .wc-block-formatted-money-amount',
            '.wc-block-components-order-summary-item .wc-block-formatted-money-amount',
            
            // انتخابگرهای Elementor
            '.elementor-price .woocommerce-Price-amount',
            '.elementor-widget-woocommerce-menu-cart .woocommerce-Price-amount',
            
            // انتخابگرهای صفحات خاص
            '.cart-total .woocommerce-Price-amount',
            '.order-total .woocommerce-Price-amount',
            '.woocommerce-checkout-review-order-table .woocommerce-Price-amount',
            '.shop_table .woocommerce-Price-amount',
            '.cart_item .woocommerce-Price-amount',
            '.product-price .woocommerce-Price-amount'
        ];
        
        return Array.from(document.querySelectorAll(selectors.join(', ')));
    }
    
    /**
     * پردازش عنصر واحد
     */
    processElement(element) {
        if (element.getAttribute(this.config.processedAttribute)) {
            return;
        }

        if (element.querySelector(`.${this.config.iconClass}`)) {
            this.log('آیکن از قبل وجود دارد، پردازش رد شد');
            element.setAttribute(this.config.processedAttribute, 'true');
            element.setAttribute(this.config.positionAttribute, this.currencyPosition);
            this.showElementImmediately(element);
            return;
        }
        
        const textContent = element.textContent || '';
        const innerHTML = element.innerHTML || '';
        
        if (!textContent.includes(this.config.tokenPattern) && 
            !this.shouldHaveIcon(element)) {
            return;
        }
        
        try {
            this.log('پردازش عنصر:', element);
            
            if (innerHTML.includes(this.config.tokenPattern)) {
                this.replaceTokenWithIcon(element);
            } else if (this.shouldHaveIcon(element) && !element.querySelector(`.${this.config.iconClass}`)) {
                this.addIconToElement(element);
            }
            
            this.applyCorrectPositionForced(element);
            
            element.setAttribute(this.config.processedAttribute, 'true');
            element.setAttribute(this.config.positionAttribute, this.currencyPosition);
            
            this.showElementImmediately(element);
            
        } catch (error) {
            console.error("❌ خطا در پردازش عنصر:", error, element);
        }
    }

    /**
     * Fallback for FOUC in case processing fails or is delayed
     */
    setupFOUCFallback() {
        setTimeout(() => {
            document.querySelectorAll(`[class*="Price"]:not([${this.config.processedAttribute}])`).forEach(el => {
                this.showElementImmediately(el);
                this.log("FOUC fallback: نمایش عنصر پردازش نشده", el);
            });
        }, 1500); // 1.5 seconds fallback
        this.log("FOUC fallback timer تنظیم شد");
    }

    /**
     * بررسی نیاز عنصر به آیکن
     */
    shouldHaveIcon(element) {
        const text = element.textContent;
        
        if (!/\d/.test(text)) return false;
        
        const relevantClasses = [
            'woocommerce-Price-amount',
            'price',
            'amount',
            'wc-block-formatted-money-amount',
            'wc-block-components-formatted-money-amount',
            'wc-block-components-product-price',
            'wc-block-components-product-price__value',
            'wc-block-components-product-price__regular',
            'wc-block-components-product-price__sale',
            'wc-block-cart-item__price',
            'wc-block-components-order-summary-item__price',
            'wc-block-components-totals-item__value'
        ];
        
        return relevantClasses.some(className => 
            element.classList.contains(className) ||
            element.closest(`.${className}`) ||
            element.closest(`[class*="${className}"]`)
        );
    }
    
    /**
     * جایگزینی توکن با آیکن
     */
    replaceTokenWithIcon(element) {
        if (element.querySelector(`.${this.config.iconClass}`)) {
            this.log("آیکن از قبل وجود دارد، جایگزینی رد شد");
            return;
        }
        const iconElement = this.createIconElement();
        const newContent = element.innerHTML.replace(
            new RegExp(this.escapeRegExp(this.config.tokenPattern), 'g'),
            iconElement.outerHTML
        );
        element.innerHTML = newContent;
        this.log('توکن جایگزین شد با آیکن');
    }
    
    /**
     * اضافه کردن آیکن به عنصر
     */
    addIconToElement(element) {
        if (element.querySelector(`.${this.config.iconClass}`)) {
            this.log("آیکن از قبل وجود دارد، افزودن رد شد");
            return;
        }

        const iconElement = this.createIconElement();
        
        if (this.currencyPosition.includes('left')) {
            element.prepend(iconElement);
        } else {
            element.appendChild(iconElement);
        }
        this.log('آیکن اضافه شد به عنصر');
    }
    
    /**
     * ایجاد عنصر آیکن
     */
    createIconElement() {
        const icon = document.createElement('span');
        icon.className = this.config.iconClass;
        icon.setAttribute('aria-label', 'تومان');
        icon.setAttribute('role', 'img');
        
        if (typeof currencySettings !== 'undefined' && currencySettings.svg_url) {
            icon.style.backgroundImage = `url('${currencySettings.svg_url}')`;
        }
        
        return icon;
    }
    
    /**
     * اعمال موقعیت صحیح با اجبار کامل
     */
    applyCorrectPositionForced(element) {
        const icon = element.querySelector(`.${this.config.iconClass}`);
        if (!icon) return;
        
        icon.remove();
        
        if (this.currencyPosition.includes('left')) {
            element.prepend(icon);
        } else {
            element.appendChild(icon);
        }
        
        const flexDirection = this.currencyPosition.includes('left') ? 'row' : 'row-reverse';
        const gap = this.currencyPosition.includes('_space') ? '4px' : '2px';
        const iconOrder = this.currencyPosition.includes('left') ? '-1' : '1';
        
        element.style.setProperty('display', 'inline-flex', 'important');
        element.style.setProperty('align-items', 'center', 'important');
        element.style.setProperty('flex-direction', flexDirection, 'important');
        element.style.setProperty('gap', gap, 'important');
        
        icon.style.setProperty('order', iconOrder, 'important');
        icon.style.setProperty('flex-shrink', '0', 'important');
        
        this.log('موقعیت اعمال شد با inline styles:', { flexDirection, gap, iconOrder });
    }
    
    /**
     * نمایش فوری عنصر
     */
    showElementImmediately(element) {
        element.style.visibility = 'visible';
        element.style.opacity = '1';
        this.log('عنصر نمایش داده شد');
    }
    
    /**
     * راه‌اندازی React integration
     */
    setupReactIntegration() {
        this.watchReactComponents();
        this.hookToReactLifecycle();
        this.log('React integration راه‌اندازی شد');
    }
    
    /**
     * Hook به React lifecycle
     */
    hookToReactLifecycle() {
        try {
            if (window.React && window.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED) {
                const ReactInternals = window.React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
                
                if (ReactInternals.Scheduler && ReactInternals.Scheduler.unstable_scheduleCallback) {
                    const originalSchedule = ReactInternals.Scheduler.unstable_scheduleCallback;
                    ReactInternals.Scheduler.unstable_scheduleCallback = (...args) => {
                        const result = originalSchedule.apply(ReactInternals.Scheduler, args);
                        setTimeout(() => this.queueProcessing(), 500);
                        return result;
                    };
                }
            }
        } catch (error) {
            this.log('نتوانست به React lifecycle hook شود:', error);
        }
    }
    
    /**
     * مراقبت از React components
     */
    watchReactComponents() {
        const reactContainers = document.querySelectorAll(`
            .wc-block-cart,
            .wc-block-checkout,
            .wc-block-mini-cart,
            .elementor-widget-woocommerce-menu-cart,
            .woocommerce-checkout-review-order-table,
            .wc-block-cart-items,
            .wc-block-checkout-order-summary
        `);
        
        reactContainers.forEach(container => {
            const attrObserver = new MutationObserver(() => {
                this.log('React container attribute تغییر کرد');
                this.queueProcessing();
            });
            
            attrObserver.observe(container, {
                attributes: true,
                attributeFilter: ['class', 'data-block-name', 'style']
            });
            
            this.observers.add(attrObserver);
        });
    }
    
    /**
     * راه‌اندازی event handlers
     */
    setupEventHandlers() {
        document.addEventListener('updated_wc_div', () => {
            this.log('updated_wc_div event');
            setTimeout(() => this.queueProcessing(), 30);
        });
        
        document.addEventListener('updated_cart_totals', () => {
            this.log('updated_cart_totals event');
            setTimeout(() => this.queueProcessing(), 30);
        });
        
        document.addEventListener('updated_checkout', () => {
            this.log('updated_checkout event');
            setTimeout(() => this.queueProcessing(), 50);
        });
        
        document.addEventListener('change', (e) => {
            if (e.target.matches('input[name="quantity"], select[name*="variation"]')) {
                this.log('Form input تغییر کرد');
                setTimeout(() => this.queueProcessing(), 100);
            }
        });
        
        if (typeof jQuery !== 'undefined') {
            jQuery(document).on('updated_cart_totals updated_checkout', () => {
                this.log('jQuery WooCommerce event');
                setTimeout(() => this.queueProcessing(), 50);
            });
            
            jQuery(document.body).on('added_to_cart', () => {
                this.log('added_to_cart event');
                setTimeout(() => this.queueProcessing(), 100);
            });
        }
        
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/global', () => {
                this.log('Elementor global ready');
                setTimeout(() => this.queueProcessing(), 100);
            });
            
            elementorFrontend.hooks.addAction('frontend/element_ready/woocommerce-product-price.default', () => {
                this.log('Elementor product price ready');
                setTimeout(() => this.queueProcessing(), 30);
            });
            
            elementorFrontend.hooks.addAction('frontend/element_ready/woocommerce-menu-cart.default', () => {
                this.log('Elementor menu cart ready');
                setTimeout(() => this.queueProcessing(), 50);
            });
        }
        
        this.log('Event handlers راه‌اندازی شدند');
    }
    
    /**
     * راه‌اندازی نظارت مداوم
     */
    setupContinuousMonitoring() {
        setInterval(() => {
            const unprocessedElements = this.findAllPriceElements().filter(element => 
                !element.getAttribute(this.config.processedAttribute)
            );
            
            if (unprocessedElements.length > 0) {
                this.log(`🔍 نظارت مداوم: ${unprocessedElements.length} عنصر پردازش نشده یافت شد`);
                unprocessedElements.forEach(element => this.processElement(element));
            }
        }, 2000);
        
        this.log('نظارت مداوم راه‌اندازی شد');
    }
    
    /**
     * Escape RegExp
     */
    escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    /**
     * Log helper
     */
    log(...args) {
        if (this.config.debugMode) {
            console.log('🔧 Ultimate Final Currency Manager:', ...args);
        }
    }
    
    /**
     * نابودی و پاک‌سازی
     */
    destroy() {
        this.log('🧹 شروع پاک‌سازی...');
        
        this.observers.forEach(observer => observer.disconnect());
        this.observers.clear();
        
        this.cache.clear();
        
        const styles = ['ultimate-final-fouc-prevention', 'ultimate-final-advanced-fouc-prevention'];
        styles.forEach(id => {
            const style = document.getElementById(id);
            if (style) style.remove();
        });
        
        document.body.classList.remove('ultimate-final-currency-manager-active');
        document.body.removeAttribute(this.config.positionAttribute);
        
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        
        this.isInitialized = false;
        this.isProcessing = false;
        this.processingQueue = [];
        
        this.log('✅ پاک‌سازی کامل شد');
    }
    
    /**
     * اطلاعات debug
     */
    getDebugInfo() {
        return {
            isInitialized: this.isInitialized,
            currencyPosition: this.currencyPosition,
            observersCount: this.observers.size,
            cacheSize: this.cache.size,
            processedElements: document.querySelectorAll(`[${this.config.processedAttribute}]`).length,
            pendingElements: document.querySelectorAll(`.woocommerce-Price-amount:not([${this.config.processedAttribute}]), .wc-block-formatted-money-amount:not([${this.config.processedAttribute}]), .wc-block-components-product-price:not([${this.config.processedAttribute}])`).length,
            debugMode: this.config.debugMode,
            forceInlineStyles: this.forceInlineStyles,
            allPriceElements: this.findAllPriceElements().length
        };
    }
    
    /**
     * اجبار پردازش مجدد تمام عناصر
     */
    forceReprocessAll() {
        this.log('🔄 اجبار پردازش مجدد تمام عناصر...');
        
        const processedElements = document.querySelectorAll(`[${this.config.processedAttribute}]`);
        processedElements.forEach(element => {
            element.removeAttribute(this.config.processedAttribute);
            element.removeAttribute(this.config.positionAttribute);
        });
        
        this.processExistingElementsImmediately();
        
        this.log('✅ پردازش مجدد کامل شد');
    }
    
    /**
     * تست موقعیت نماد
     */
    testCurrencyPosition() {
        this.log('🧪 تست موقعیت نماد...');
        
        const elements = this.findAllPriceElements();
        const results = {
            total: elements.length,
            processed: 0,
            correctPosition: 0,
            wrongPosition: 0,
            details: []
        };
        
        elements.forEach(element => {
            const isProcessed = element.getAttribute(this.config.processedAttribute);
            const icon = element.querySelector(`.${this.config.iconClass}`);
            
            if (isProcessed) {
                results.processed++;
                
                if (icon) {
                    const elementStyle = window.getComputedStyle(element);
                    const flexDirection = elementStyle.flexDirection;
                    const expectedDirection = this.currencyPosition.includes('left') ? 'row' : 'row-reverse';
                    
                    if (flexDirection === expectedDirection) {
                        results.correctPosition++;
                    } else {
                        results.wrongPosition++;
                        results.details.push({
                            element: element,
                            expected: expectedDirection,
                            actual: flexDirection,
                            classes: element.className
                        });
                    }
                }
            }
        });
        
        console.table(results);
        if (results.details.length > 0) {
            console.log('عناصر با موقعیت اشتباه:', results.details);
        }
        
        return results;
    }
}

// ایجاد instance جهانی
const ultimateFinalCurrencyManager = new UltimateFinalCurrencyManager();

// راه‌اندازی خودکار
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        ultimateFinalCurrencyManager.initialize();
    });
} else {
    ultimateFinalCurrencyManager.initialize();
}

// صادر کردن برای استفاده خارجی
window.ultimateFinalCurrencyManager = ultimateFinalCurrencyManager;
window.replaceCurrencyIcon = () => ultimateFinalCurrencyManager.queueProcessing();
window.applyCurrencyPosition = () => ultimateFinalCurrencyManager.queueProcessing();
window.forceReprocessCurrency = () => ultimateFinalCurrencyManager.forceReprocessAll();

// Debug helpers
window.currencyDebug = () => {
    console.table(ultimateFinalCurrencyManager.getDebugInfo());
};

window.enableCurrencyDebug = () => {
    ultimateFinalCurrencyManager.config.debugMode = true;
    console.log('🔧 Debug mode فعال شد');
};

window.disableCurrencyDebug = () => {
    ultimateFinalCurrencyManager.config.debugMode = false;
    console.log('🔧 Debug mode غیرفعال شد');
};

window.testCurrencyPosition = () => {
    return ultimateFinalCurrencyManager.testCurrencyPosition();
};

console.log(' Ultimate Final Currency Manager loaded successfully');

