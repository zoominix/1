<?php
add_action('wp_ajax_zoominix_get_orders', 'zoominix_get_orders_callback');
add_action('wp_ajax_nopriv_zoominix_get_orders', 'zoominix_get_orders_callback');

function zoominix_get_orders_callback() {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'باید وارد شوید']);
    }

    $user_id = get_current_user_id();
    $status  = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'all';
    $search  = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
    $offset  = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
    $limit   = 5;

    $args = [
        'customer' => $user_id,
        'limit'    => 50,
        'orderby'  => 'date',
        'order'    => 'DESC',
    ];

    if ($status && $status !== 'all') {
        $args['status'] = $status;
    }

    $all_orders = wc_get_orders($args);

    // اجرای فیلتر search روی order_id
    $filtered = [];
    foreach ($all_orders as $order) {
        if ($search && stripos((string)$order->get_id(), $search) === false) continue;
        $filtered[] = $order;
    }

    $has_more = count($filtered) > ($offset + $limit);
    $orders_to_show = array_slice($filtered, $offset, $limit);

    ob_start();
    foreach ($orders_to_show as $order) {
        wc_get_template('order-card.php', ['order' => $order], '', get_stylesheet_directory() . '/inc/myaccount-orders/templates/');
    }
    $html = ob_get_clean();

    wp_send_json_success([
        'data'     => $html,
        'has_more' => $has_more,
    ]);
}
