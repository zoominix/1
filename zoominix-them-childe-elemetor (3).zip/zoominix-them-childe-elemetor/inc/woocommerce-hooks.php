<?php
//  ---------------------
add_filter( 'woocommerce_account_menu_items', 'remove_downloads_from_account_menu' );
function remove_downloads_from_account_menu( $items ) {
    unset( $items['downloads'] );
    return $items;
}
add_action( 'template_redirect', 'redirect_downloads_page' );
function redirect_downloads_page() {
    if ( is_account_page() && is_wc_endpoint_url('downloads') ) {
        wp_safe_redirect( wc_get_page_permalink('myaccount') );
        exit;
    }
}
add_filter( 'woocommerce_get_query_vars', 'remove_downloads_endpoint' );
function remove_downloads_endpoint( $endpoints ) {
    unset( $endpoints['downloads'] );
    return $endpoints;
}
//--------------------

//-------darsasd takhfif------------
add_filter('woocommerce_sale_flash', 'custom_woocommerce_sale_flash', 10, 3);
function custom_woocommerce_sale_flash($html, $post, $product) {
    if ($product->is_type('simple')) {
        $regular_price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();
        if ($regular_price && $sale_price) {
            $percentage = round((($regular_price - $sale_price) / $regular_price) * 100);
            $html = '<span class="onsale">' . $percentage . '<span class="small-percent">%</span></span>';
        }
    }
    return $html;
}
// seprator
add_filter('woocommerce_breadcrumb_defaults', 'custom_woocommerce_breadcrumb_separator');
function custom_woocommerce_breadcrumb_separator($defaults) {
    $defaults['delimiter'] = ' &raquo; ';
    return $defaults;
}
//--------gravator-----
function zoominix_custom_review_callback($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    ?>
    <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
        <div class="comment_container">
            <div class="avatar-wrapper">
                <lottie-player
                    src="<?php echo get_stylesheet_directory_uri(); ?>/assets/lottie/bobble-product.json"
                    background="transparent"
                    speed="1"
                    style="width: 80px; height: 80px; position: absolute; top: 0; left: 0;"
                    loop
                    autoplay>
                </lottie-player>
                <?php echo get_avatar($comment, 60); ?>
            </div>
            <div class="comment-text">
                <div class="meta">
                    <strong><?php comment_author(); ?></strong>
                    <span><?php comment_date(); ?></span>
                </div>
                <div class="description">
                    <?php comment_text(); ?>
                </div>
            </div>
        </div>
    </li>
    <?php
}
//stars
add_filter('woocommerce_product_get_rating_html', 'custom_wc_rating_text', 10, 3);
function custom_wc_rating_text($rating_html, $rating, $count) {
    if ($rating > 0) {
        $rating_html .= '<span class="custom-rating-text"> ' . number_format($rating, 1) . '</span>';
    }
    return $rating_html;
}