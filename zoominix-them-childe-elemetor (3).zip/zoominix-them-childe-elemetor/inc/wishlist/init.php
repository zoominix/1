<?php
/**
 * Wishlist Init File
 * Load wishlist scripts, styles and functionalities
 */

defined('ABSPATH') || exit;

/**
 * Enqueue wishlist scripts and styles
 */
function zoominix_enqueue_wishlist_assets() {
    // مسیر قالب فرزند
    $theme_dir = get_stylesheet_directory_uri();

    // صفحه علاقه‌مندی‌ها (بر اساس slug)
    if (is_page('wishlistpage')) {
        // JS مخصوص صفحه علاقه‌مندی‌ها
        wp_enqueue_script(
            'zoominix-wishlist-page-js',
            $theme_dir . '/inc/wishlist/js/wishlist-page.js',
            [],
            '1.0',
            true
        );
        // CSS اختصاصی شما برای صفحه wishlist (مسیری که خودت می‌ذاری)
        wp_enqueue_style(
            'zoominix-wishlist-page-css',
            $theme_dir . '/inc/wishlist/assets/css/wishlist-style.css',
            [],
            '1.0'
        );
    }

    // صفحه محصول
    if (is_product()) {
        // JS مخصوص صفحه محصول
        wp_enqueue_script(
            'zoominix-wishlist-product-js',
            $theme_dir . '/inc/wishlist/assets/js/wishlist-product.js',
            [],
            '1.0',
            true
        );

    }

    // داده‌های AJAX و nonce
    wp_localize_script('zoominix-wishlist-product-js', 'zoominixWishlist', [
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('zoominix_wishlist_nonce')
    ]);
}
// تزریق product_id به جاوااسکریپت
add_action('wp_footer', function() {
    if (is_product()) {
        echo '<script>var zoominix_product_id = ' . get_the_ID() . ';</script>';
    }
});

add_action('wp_enqueue_scripts', 'zoominix_enqueue_wishlist_assets');

/**
 * Include Wishlist Logic
 */
require_once get_stylesheet_directory() . '/inc/wishlist/ajax.php';
require_once get_stylesheet_directory() . '/inc/wishlist/template-functions.php';
