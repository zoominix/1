(function($){
  $(window).on('elementor/frontend/init', function() {
    const svg        = d3.select("#main-svg");
    const morph      = svg.select("#morph-shape");
    const pathSquare = morph.attr("d");
    const pathStar   = morph.attr("data-original");
    let   isSquare   = true;

    svg.on("click", function() {
      d3.select("#clip-path").attr("d", morph.attr("d"));

      const node = morph.node();
      const bbox = node.getBBox();
      const points = [];
      const N = 50;
      while (points.length < N) {
        const x = bbox.x + Math.random() * bbox.width;
        const y = bbox.y + Math.random() * bbox.height;
        points.push([x, y]);
      }

      const voronoi = d3.voronoi()
                        .extent([[bbox.x, bbox.y], [bbox.x + bbox.width, bbox.y + bbox.height]]);
      const diagram = voronoi(points);
      const polys   = diagram.polygons();

      morph.remove();
      const fragG = svg.append("g")
                       .attr("id", "fragments")
                       .attr("clip-path", "url(#shape-clip)");

      fragG.selectAll("path")
        .data(polys)
        .enter()
        .append("path")
        .attr("class", "piece")
        .attr("d", d => "M" + d.join("L") + "Z")
        .each(function() {
          gsap.to(this, {
            duration: 0.6,
            x: (Math.random() - 0.5) * 150,
            y: (Math.random() - 0.5) * 150,
            rotation: Math.random() * 360,
            opacity: 0,
            ease: "power2.out",
            delay: Math.random() * 0.2
          });
        });

      setTimeout(() => {
        svg.select("#fragments").remove();

        morph
          .attr("d", isSquare ? pathStar : pathSquare)
          .attr("transform", "matrix(1,0,0,1,11,0)");

        svg.node().appendChild(morph.node());

        const cx = bbox.x + bbox.width / 2;
        const cy = bbox.y + bbox.height / 2;
        gsap.fromTo(morph.node(), {
          scale: 0,
          opacity: 0,
          transformOrigin: `${cx}px ${cy}px`
        }, {
          duration: 0.5,
          scale: 1,
          opacity: 1,
          ease: "back.out(1.7)"
        });

        isSquare = !isSquare;

        // ✅ بازگردانی پنل به حالت اولیه در صورت باقی ماندن
        const panel = document.querySelector('.e-off-canvas');
        if (panel) {
          panel.classList.remove('e-off-canvas--active');
          panel.setAttribute('aria-hidden', 'true');
        }
        document.body.classList.remove('e-off-canvas-open');

        // ✅ کلیک مصنوعی استاندارد برای باز کردن پنل
        setTimeout(() => {
          const trigger = document.querySelector('#my-offcanvas-trigger');
          if (trigger) {
            const evt = new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window
            });
            trigger.dispatchEvent(evt);
          }
        }, 200);

      }, 800);
    });
  });
})(jQuery);
