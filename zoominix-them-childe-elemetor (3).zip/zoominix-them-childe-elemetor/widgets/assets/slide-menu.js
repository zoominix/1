/**
 * Zoominix Slide Menu JavaScript
 * 
 * Handles the slide animation and interaction for the menu widget.
 * 
 * @package Zoominix\Elementor\Widgets
 * @since 1.0.0
 */

document.addEventListener("DOMContentLoaded", function() {
    /**
     * Initialize all slide menu instances on the page
     */
    function initSlideMenus() {
        const menuContainers = document.querySelectorAll('.zoominix-slide-menu-container');
        
        menuContainers.forEach(container => {
            initSingleMenu(container);
        });
    }
    
    /**
     * Initialize a single slide menu instance
     * 
     * @param {HTMLElement} container - The menu container element
     */
    function initSingleMenu(container) {
        // Get all panels in this menu
        const panels = container.querySelectorAll('.menu-panel');
        
        // Set up click handlers for menu items with children
        const menuItemsWithChildren = container.querySelectorAll('.has-children a');
        menuItemsWithChildren.forEach(item => {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const targetPanelId = this.getAttribute('data-target-panel');
                const currentPanel = this.closest('.menu-panel');
                const targetPanel = document.getElementById(targetPanelId);
                
                if (targetPanel) {
                    slideToPanel(currentPanel, targetPanel, container);
                }
            });
        });
        
        // Set up click handlers for back buttons
        const backButtons = container.querySelectorAll('.back-button');
        backButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const targetPanelId = this.getAttribute('data-target-panel');
                const currentPanel = this.closest('.menu-panel');
                const targetPanel = document.getElementById(targetPanelId);
                
                if (targetPanel) {
                    slideBackToPanel(currentPanel, targetPanel, container);
                }
            });
        });
        
        // Initialize container height based on active panel
        updateContainerHeight(container);
    }
    
    /**
     * Slide from current panel to target panel
     * 
     * @param {HTMLElement} currentPanel - The currently active panel
     * @param {HTMLElement} targetPanel - The panel to slide to
     * @param {HTMLElement} container - The menu container element
     */
    function slideToPanel(currentPanel, targetPanel, container) {
        // Set initial position for target panel (off-screen to the left)
        targetPanel.style.transform = 'translateX(-100%)';
        targetPanel.style.opacity = '1';
        targetPanel.style.visibility = 'visible';
        
        // Force browser to recognize the above style changes before animating
        setTimeout(() => {
            // Slide current panel out to the right
            currentPanel.style.transform = 'translateX(100%)';
            currentPanel.setAttribute('data-active', 'false');
            
            // Slide target panel in from the left
            targetPanel.style.transform = 'translateX(0)';
            targetPanel.setAttribute('data-active', 'true');
            
            // Update container height to match the new active panel
            updateContainerHeight(container);
            
            // Clean up styles after transition
            setTimeout(() => {
                currentPanel.style.opacity = '0';
                currentPanel.style.visibility = 'hidden';
                
                // Remove inline styles to let CSS take over again
                currentPanel.style.transform = '';
                targetPanel.style.transform = '';
            }, 300); // Match this with the CSS transition duration
        }, 50);
    }
    
    /**
     * Slide back from current panel to parent panel
     * 
     * @param {HTMLElement} currentPanel - The currently active panel
     * @param {HTMLElement} targetPanel - The parent panel to slide back to
     * @param {HTMLElement} container - The menu container element
     */
    function slideBackToPanel(currentPanel, targetPanel, container) {
        // Set initial position for target panel (off-screen to the right)
        targetPanel.style.transform = 'translateX(100%)';
        targetPanel.style.opacity = '1';
        targetPanel.style.visibility = 'visible';
        
        // Force browser to recognize the above style changes before animating
        setTimeout(() => {
            // Slide current panel out to the left
            currentPanel.style.transform = 'translateX(-100%)';
            currentPanel.setAttribute('data-active', 'false');
            
            // Slide target panel in from the right
            targetPanel.style.transform = 'translateX(0)';
            targetPanel.setAttribute('data-active', 'true');
            
            // Update container height to match the new active panel
            updateContainerHeight(container);
            
            // Clean up styles after transition
            setTimeout(() => {
                currentPanel.style.opacity = '0';
                currentPanel.style.visibility = 'hidden';
                
                // Remove inline styles to let CSS take over again
                currentPanel.style.transform = '';
                targetPanel.style.transform = '';
            }, 300); // Match this with the CSS transition duration
        }, 50);
    }
    
    /**
     * Update the container height to match the active panel
     * 
     * @param {HTMLElement} container - The menu container element
     */
    function updateContainerHeight(container) {
        const activePanel = container.querySelector('.menu-panel[data-active="true"]');
        
        if (activePanel) {
            const panelHeight = activePanel.offsetHeight;
            container.style.height = panelHeight + 'px';
        }
    }
    
    // Initialize all menus when DOM is ready
    initSlideMenus();
    
    // Update container heights when window is resized
    window.addEventListener('resize', function() {
        const menuContainers = document.querySelectorAll('.zoominix-slide-menu-container');
        menuContainers.forEach(container => {
            updateContainerHeight(container);
        });
    });
});
