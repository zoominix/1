<?php
/**
 * Custom Elementor Widget - Zoominix Slide Menu
 *
 * @package Zoominix\Elementor\Widgets
 */

namespace Zoominix\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Slide Menu Widget
 *
 * A customizable slide menu widget for Elementor with advanced styling options.
 *
 * @since 1.0.0
 */
class Slide_Menu_Widget extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve slide menu widget name.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget name.
     */
    public function get_name() {
        return 'zoominix_slide_menu';
    }

    /**
     * Get widget title.
     *
     * Retrieve slide menu widget title.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('منوی اسلایدی (جدید)', 'zoominix-slide-menu');
    }

    /**
     * Get widget icon.
     *
     * Retrieve slide menu widget icon.
     *
     * @since 1.0.0
     * @access public
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-menu-bar';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the slide menu widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget categories.
     */
    public function get_categories() {
        return ['general'];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the slide menu widget belongs to.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return ['menu', 'nav', 'slide', 'mobile', 'navigation'];
    }

    /**
     * Get script dependencies.
     *
     * Retrieve the list of script dependencies the slide menu widget depends on.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget script dependencies.
     */
    public function get_script_depends() {
        return ['zoominix-slide-menu-script'];
    }

    /**
     * Get style dependencies.
     *
     * Retrieve the list of style dependencies the slide menu widget depends on.
     *
     * @since 1.0.0
     * @access public
     * @return array Widget style dependencies.
     */
    public function get_style_depends() {
        return ['zoominix-slide-menu-style'];
    }

    /**
     * Register widget controls.
     *
     * Add input fields to allow the user to customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls() {
        // Content Section - Menu Selection
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('تنظیمات منو', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $menus = $this->get_available_menus();
        
        if (!empty($menus)) {
            $this->add_control(
                'menu_id',
                [
                    'label' => esc_html__('انتخاب منو', 'zoominix-slide-menu'),
                    'type' => Controls_Manager::SELECT,
                    'options' => $menus,
                    'default' => array_keys($menus)[0],
                    'description' => sprintf(
                        /* translators: %s: URL to create a new menu */
                        esc_html__('برای ایجاد منوی جدید %s را کلیک کنید.', 'zoominix-slide-menu'),
                        sprintf(
                            '<a href="%s" target="_blank">%s</a>',
                            admin_url('nav-menus.php?action=edit&menu=0'),
                            esc_html__('اینجا', 'zoominix-slide-menu')
                        )
                    ),
                ]
            );
        } else {
            $this->add_control(
                'menu_id',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => sprintf(
                        /* translators: %s: URL to create a new menu */
                        esc_html__('<strong>هیچ منویی یافت نشد</strong><br>برای ایجاد منوی جدید %s را کلیک کنید.', 'zoominix-slide-menu'),
                        sprintf(
                            '<a href="%s" target="_blank">%s</a>',
                            admin_url('nav-menus.php?action=edit&menu=0'),
                            esc_html__('اینجا', 'zoominix-slide-menu')
                        )
                    ),
                    'separator' => 'after',
                ]
            );
        }

        $this->add_control(
            'direction',
            [
                'label' => esc_html__('جهت متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'rtl' => esc_html__('راست به چپ (RTL)', 'zoominix-slide-menu'),
                    'ltr' => esc_html__('چپ به راست (LTR)', 'zoominix-slide-menu'),
                ],
                'default' => 'rtl',
                'prefix_class' => 'zoominix-menu-direction-',
                'selectors' => [
                    '{{WRAPPER}} .zoominix-slide-menu-container' => 'direction: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Container Style Section
        $this->start_controls_section(
            'section_container_style',
            [
                'label' => esc_html__('استایل کانتینر', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_min_height',
            [
                'label' => esc_html__('حداقل ارتفاع', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                        'step' => 10,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .zoominix-slide-menu-container' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => esc_html__('پدینگ کانتینر', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .zoominix-slide-menu-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_border_radius',
            [
                'label' => esc_html__('گردی گوشه‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .zoominix-slide-menu-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_box_shadow',
                'selector' => '{{WRAPPER}} .zoominix-slide-menu-container',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .zoominix-slide-menu-container',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'container_background',
                'label' => esc_html__('پس زمینه', 'zoominix-slide-menu'),
                'types' => ['classic', 'gradient', 'video'],
                'selector' => '{{WRAPPER}} .zoominix-slide-menu-container',
            ]
        );

        $this->end_controls_section();

        // Panel Style Section
        $this->start_controls_section(
            'section_panel_style',
            [
                'label' => esc_html__('استایل پنل‌ها', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'panel_padding',
            [
                'label' => esc_html__('پدینگ پنل‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .menu-panel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '20',
                    'right' => '20',
                    'bottom' => '20',
                    'left' => '20',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        $this->add_control(
            'panel_background_color',
            [
                'label' => esc_html__('رنگ پس زمینه پنل‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel' => 'background-color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'enable_panel_scroll',
            [
                'label' => esc_html__('فعال‌سازی اسکرول پنل', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('فعال', 'zoominix-slide-menu'),
                'label_off' => esc_html__('غیرفعال', 'zoominix-slide-menu'),
                'return_value' => 'yes',
                'default' => 'yes',
                'selectors' => [
                    '{{WRAPPER}} .menu-panel' => 'overflow-y: {{VALUE}} === "yes" ? "auto" : "hidden";',
                ],
            ]
        );

        $this->add_responsive_control(
            'panel_max_height',
            [
                'label' => esc_html__('حداکثر ارتفاع پنل', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                        'step' => 10,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .menu-panel' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'enable_panel_scroll' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Menu Items Style Section
        $this->start_controls_section(
            'section_menu_items_style',
            [
                'label' => esc_html__('استایل آیتم‌های منو', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_items_typography',
                'label' => esc_html__('تایپوگرافی آیتم‌ها', 'zoominix-slide-menu'),
                'selector' => '{{WRAPPER}} .menu-panel li a',
            ]
        );

        $this->add_responsive_control(
            'menu_items_padding',
            [
                'label' => esc_html__('پدینگ آیتم‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '12',
                    'right' => '15',
                    'bottom' => '12',
                    'left' => '15',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_items_spacing',
            [
                'label' => esc_html__('فاصله بین آیتم‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
            ]
        );

        $this->start_controls_tabs('menu_items_style_tabs');

        $this->start_controls_tab(
            'menu_items_normal_tab',
            [
                'label' => esc_html__('عادی', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'menu_items_text_color',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'color: {{VALUE}};',
                ],
                'default' => '#333333',
            ]
        );

        $this->add_control(
            'menu_items_background_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'background-color: {{VALUE}};',
                ],
                'default' => '#f2f2f2',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'menu_items_hover_tab',
            [
                'label' => esc_html__('هاور', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'menu_items_text_color_hover',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'menu_items_background_color_hover',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a:hover' => 'background-color: {{VALUE}};',
                ],
                'default' => '#f9f9f9',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'menu_items_border_heading',
            [
                'label' => esc_html__('خط جداکننده آیتم‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'menu_items_border_style',
            [
                'label' => esc_html__('نوع خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('بدون خط', 'zoominix-slide-menu'),
                    'solid' => esc_html__('خط ساده', 'zoominix-slide-menu'),
                    'dashed' => esc_html__('خط خط', 'zoominix-slide-menu'),
                    'dotted' => esc_html__('نقطه نقطه', 'zoominix-slide-menu'),
                    'double' => esc_html__('دوتایی', 'zoominix-slide-menu'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'border-bottom-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'menu_items_border_color',
            [
                'label' => esc_html__('رنگ خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'border-bottom-color: {{VALUE}};',
                ],
                'default' => '#f0f0f0',
                'condition' => [
                    'menu_items_border_style!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'menu_items_border_width',
            [
                'label' => esc_html__('ضخامت خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .menu-panel li a' => 'border-bottom-width: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
                'condition' => [
                    'menu_items_border_style!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'submenu_indicator_heading',
            [
                'label' => esc_html__('نشانگر زیرمنو', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'submenu_indicator_color',
            [
                'label' => esc_html__('رنگ نشانگر', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .submenu-indicator' => 'border-color: {{VALUE}};',
                ],
                'default' => '#888888',
            ]
        );

        $this->add_responsive_control(
            'submenu_indicator_size',
            [
                'label' => esc_html__('اندازه نشانگر', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 4,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .submenu-indicator' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
            ]
        );

        $this->add_responsive_control(
            'submenu_indicator_thickness',
            [
                'label' => esc_html__('ضخامت نشانگر', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 5,
                        'step' => 0.5,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .submenu-indicator' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 2,
                ],
            ]
        );

        $this->end_controls_section();

        // Back Button Style Section
        $this->start_controls_section(
            'section_back_button_style',
            [
                'label' => esc_html__('استایل دکمه بازگشت', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'back_button_typography',
                'label' => esc_html__('تایپوگرافی', 'zoominix-slide-menu'),
                'selector' => '{{WRAPPER}} .back-button',
            ]
        );

        $this->add_responsive_control(
            'back_button_padding',
            [
                'label' => esc_html__('پدینگ', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .back-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '5',
                    'right' => '0',
                    'bottom' => '5',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        $this->add_responsive_control(
            'back_button_margin',
            [
                'label' => esc_html__('مارجین', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .back-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('back_button_style_tabs');

        $this->start_controls_tab(
            'back_button_normal_tab',
            [
                'label' => esc_html__('عادی', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'back_button_text_color',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .back-button' => 'color: {{VALUE}};',
                ],
                'default' => '#333333',
            ]
        );

        $this->add_control(
            'back_button_background_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .back-button' => 'background-color: {{VALUE}};',
                ],
                'default' => 'transparent',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'back_button_hover_tab',
            [
                'label' => esc_html__('هاور', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'back_button_text_color_hover',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .back-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'back_button_background_color_hover',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .back-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'back_button_border_heading',
            [
                'label' => esc_html__('حاشیه دکمه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'back_button_border',
                'selector' => '{{WRAPPER}} .back-button',
            ]
        );

        $this->add_responsive_control(
            'back_button_border_radius',
            [
                'label' => esc_html__('گردی گوشه‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .back-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'back_icon_heading',
            [
                'label' => esc_html__('آیکون بازگشت', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'back_icon_size',
            [
                'label' => esc_html__('اندازه آیکون', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .back-button .back-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
            ]
        );

        $this->add_responsive_control(
            'back_icon_spacing',
            [
                'label' => esc_html__('فاصله آیکون از متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}.zoominix-menu-direction-rtl .back-button .back-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}}.zoominix-menu-direction-ltr .back-button .back-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 8,
                ],
            ]
        );

        $this->end_controls_section();

        // View All Button Style Section
        $this->start_controls_section(
            'section_view_all_button_style',
            [
                'label' => esc_html__('استایل دکمه "دیدن همه"', 'zoominix-slide-menu'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'view_all_button_typography',
                'label' => esc_html__('تایپوگرافی', 'zoominix-slide-menu'),
                'selector' => '{{WRAPPER}} .view-all-button',
            ]
        );

        $this->add_responsive_control(
            'view_all_button_padding',
            [
                'label' => esc_html__('پدینگ', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .view-all-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '12',
                    'right' => '15',
                    'bottom' => '12',
                    'left' => '15',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        $this->add_responsive_control(
            'view_all_button_margin',
            [
                'label' => esc_html__('مارجین', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .view-all-button-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '20',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
            ]
        );

        $this->start_controls_tabs('view_all_button_style_tabs');

        $this->start_controls_tab(
            'view_all_button_normal_tab',
            [
                'label' => esc_html__('عادی', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'view_all_button_text_color',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .view-all-button' => 'color: {{VALUE}};',
                ],
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'view_all_button_background_color',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .view-all-button' => 'background-color: {{VALUE}};',
                ],
                'default' => '#d40000',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'view_all_button_hover_tab',
            [
                'label' => esc_html__('هاور', 'zoominix-slide-menu'),
            ]
        );

        $this->add_control(
            'view_all_button_text_color_hover',
            [
                'label' => esc_html__('رنگ متن', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .view-all-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'view_all_button_background_color_hover',
            [
                'label' => esc_html__('رنگ پس زمینه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .view-all-button:hover' => 'background-color: {{VALUE}};',
                ],
                'default' => '#b00000',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'view_all_button_border_heading',
            [
                'label' => esc_html__('حاشیه دکمه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'view_all_button_border',
                'selector' => '{{WRAPPER}} .view-all-button',
            ]
        );

        $this->add_responsive_control(
            'view_all_button_border_radius',
            [
                'label' => esc_html__('گردی گوشه‌ها', 'zoominix-slide-menu'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .view-all-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '5',
                    'right' => '5',
                    'bottom' => '5',
                    'left' => '5',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        $this->add_control(
            'view_all_separator_heading',
            [
                'label' => esc_html__('خط جداکننده بالای دکمه', 'zoominix-slide-menu'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'view_all_separator_style',
            [
                'label' => esc_html__('نوع خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('بدون خط', 'zoominix-slide-menu'),
                    'solid' => esc_html__('خط ساده', 'zoominix-slide-menu'),
                    'dashed' => esc_html__('خط خط', 'zoominix-slide-menu'),
                    'dotted' => esc_html__('نقطه نقطه', 'zoominix-slide-menu'),
                    'double' => esc_html__('دوتایی', 'zoominix-slide-menu'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .view-all-button-container' => 'border-top-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'view_all_separator_color',
            [
                'label' => esc_html__('رنگ خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .view-all-button-container' => 'border-top-color: {{VALUE}};',
                ],
                'default' => '#eeeeee',
                'condition' => [
                    'view_all_separator_style!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'view_all_separator_width',
            [
                'label' => esc_html__('ضخامت خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .view-all-button-container' => 'border-top-width: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
                'condition' => [
                    'view_all_separator_style!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'view_all_separator_padding',
            [
                'label' => esc_html__('پدینگ بالای خط جداکننده', 'zoominix-slide-menu'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .view-all-button-container' => 'padding-top: {{SIZE}}{{UNIT}};',
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'condition' => [
                    'view_all_separator_style!' => 'none',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Get available menus.
     *
     * Retrieve the list of available WordPress menus.
     *
     * @since 1.0.0
     * @access private
     * @return array Available WordPress menus.
     */
    private function get_available_menus() {
        $menus = wp_get_nav_menus();
        $options = [];

        foreach ($menus as $menu) {
            $options[$menu->term_id] = $menu->name;
        }

        return $options;
    }

    /**
     * Build menu tree.
     *
     * Build a hierarchical tree of menu items.
     *
     * @since 1.0.0
     * @access private
     * @param array $elements Menu items array.
     * @param int $parentId Parent ID.
     * @return array Hierarchical menu tree.
     */
    private function build_menu_tree(array $elements, $parentId = 0) {
        $branch = [];
        foreach ($elements as $element) {
            if ($element->menu_item_parent == $parentId) {
                $children = $this->build_menu_tree($elements, $element->ID);
                if ($children) {
                    $element->children = $children;
                }
                $branch[$element->ID] = $element;
            }
        }
        return $branch;
    }

    /**
     * Get item title by ID.
     *
     * Retrieve the title of a menu item by its ID.
     *
     * @since 1.0.0
     * @access private
     * @param array $items Menu items array.
     * @param int $id Item ID.
     * @return string Item title.
     */
    private function get_item_title_by_id($items, $id) {
        foreach ($items as $item) {
            if ($item->ID == $id) {
                return $item->title;
            }
        }
        return '';
    }

    /**
     * Render menu panel.
     *
     * Render a menu panel with its items and submenus.
     *
     * @since 1.0.0
     * @access private
     * @param array $items Menu items.
     * @param int $level Panel level.
     * @param string $panel_id Panel ID.
     * @param string|null $parent_panel_id Parent panel ID.
     * @param array $all_menu_items All menu items.
     * @param int|null $parent_item_id Parent item ID.
     */
    private function render_menu_panel($items, $level, $panel_id, $parent_panel_id = null, $all_menu_items, $parent_item_id = null) {
        $settings = $this->get_settings_for_display();
        $direction = $settings['direction'];
        
        echo '<div class="menu-panel" id="' . esc_attr($panel_id) . '" data-level="' . esc_attr($level) . '" ' . ($level === 0 ? 'data-active="true"' : '') . '>';
        
        // Add back button for sub-menus
        if ($parent_panel_id !== null && $parent_item_id !== null) {
            $parent_title = $this->get_item_title_by_id($all_menu_items, $parent_item_id);
            echo '<div class="menu-panel-header">';
            
            // Adjust arrow direction based on RTL/LTR setting
            $arrow = $direction === 'rtl' ? '&rarr;' : '&larr;';
            
            echo '<button class="back-button" data-target-panel="' . esc_attr($parent_panel_id) . '"><span class="back-icon">' . $arrow . '</span> ' . esc_html($parent_title) . '</button>';
            echo '</div>';
        }

        echo '<ul>';
        foreach ($items as $item) {
            $has_children = !empty($item->children);
            $link_attributes = 'href="' . esc_url($item->url) . '"';
            $li_classes = '';

            if ($has_children) {
                $child_panel_id = 'menu-panel-' . esc_attr($item->ID);
                $link_attributes = 'href="#" data-target-panel="' . esc_attr($child_panel_id) . '"';
                $li_classes = 'has-children';
            }

            echo '<li class="' . esc_attr($li_classes) . '"><a ' . $link_attributes . '>' . esc_html($item->title) . ($has_children ? '<span class="submenu-indicator"></span>' : '') . '</a></li>';
        }
        echo '</ul>';

        // "View All" button for submenus (direct child of a menu item)
        if ($level > 0 && $parent_item_id !== null) {
            $parent_item_object = null;
            foreach ($all_menu_items as $menu_item_obj) {
                if ($menu_item_obj->ID == $parent_item_id) {
                    $parent_item_object = $menu_item_obj;
                    break;
                }
            }
            if ($parent_item_object) {
                echo '<div class="view-all-button-container">';
                echo '<a href="' . esc_url($parent_item_object->url) . '" class="view-all-button">' . 
                     sprintf(esc_html__('دیدن تمام آگهی‌های %s', 'zoominix-slide-menu'), esc_html($parent_item_object->title)) . '</a>';
                echo '</div>';
            }
        }

        echo '</div>'; // .menu-panel

        // Recursively render child panels
        if (!empty($items)) {
            foreach ($items as $item) {
                if (!empty($item->children)) {
                    $child_panel_id = 'menu-panel-' . esc_attr($item->ID);
                    $this->render_menu_panel($item->children, $level + 1, $child_panel_id, $panel_id, $all_menu_items, $item->ID);
                }
            }
        }
    }

    /**
     * Render widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        $menu_id = $settings['menu_id'];

        if (!$menu_id) {
            echo '<p>' . esc_html__('لطفا یک منو انتخاب کنید.', 'zoominix-slide-menu') . '</p>';
            return;
        }

        $menu_items = wp_get_nav_menu_items($menu_id);

        if (empty($menu_items)) {
            echo '<p>' . esc_html__('منوی انتخاب شده آیتمی ندارد.', 'zoominix-slide-menu') . '</p>';
            return;
        }

        // Build a hierarchical tree of menu items
        $menu_tree = $this->build_menu_tree($menu_items);

        echo '<div class="zoominix-slide-menu-container" id="zoominix-slide-menu-container-' . esc_attr($this->get_id()) . '">';
        // Render the main menu panel (level 0)
        $this->render_menu_panel($menu_tree, 0, 'menu-panel-0', null, $menu_items);
        echo '</div>';
    }
}

// Register the widget
\Elementor\Plugin::instance()->widgets_manager->register(new Slide_Menu_Widget());
