<?php
// امنیت
defined('ABSPATH') || exit;

/**
 * شورتکد: [zoominix_wishlist_page]
 * وظیفه: نمایش div های اولیه فقط برای محصولات معتبر علاقه‌مندی‌ها
 */
add_shortcode('zoominix_wishlist_page', 'zoominix_render_wishlist_page');
function zoominix_render_wishlist_page() {
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        $meta = get_user_meta($user_id, 'zoominix_wishlist', true);
        $now = time();
        $product_ids = [];

        if (is_array($meta)) {
            foreach ($meta as $item) {
                if (
                    isset($item['product_id'], $item['timestamp']) &&
                    ($now - intval($item['timestamp'])) < 30 * DAY_IN_SECONDS
                ) {
                    $product_ids[] = intval($item['product_id']);
                }
            }

            // بروزرسانی داده‌ها بدون آیتم‌های قدیمی
            $cleaned = array_filter($meta, function ($item) use ($now) {
                return isset($item['timestamp']) && ($now - intval($item['timestamp'])) < 30 * DAY_IN_SECONDS;
            });
            update_user_meta($user_id, 'zoominix_wishlist', $cleaned);
        }

        // خروجی اگر لیست خالی بود
        if (empty($product_ids)) {
            return '<div id="zoominix-guest-wishlist"><p>لیست علاقه‌مندی‌های شما خالی است.</p></div>';
        }

        // HTML اولیه برای واکشی جاوااسکریپت
        ob_start();
        echo '<div id="zoominix-guest-wishlist">';
        foreach ($product_ids as $pid) {
            echo '<div class="wishlist-item" data-product-id="' . esc_attr($pid) . '"></div>';
        }
        echo '</div>';
        return ob_get_clean();
    } else {
        // مهمان: بدون HTML داخلی
        return '<div id="zoominix-guest-wishlist"></div>';
    }
}
