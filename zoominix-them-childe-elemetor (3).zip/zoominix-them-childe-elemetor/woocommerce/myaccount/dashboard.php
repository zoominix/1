<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$current_user   = wp_get_current_user();
$avatar_url     = get_avatar_url( $current_user->ID, ['size' => 80] );
$logout_url     = esc_url( wc_logout_url() );
$display_name   = esc_html( $current_user->display_name );
$user_meta      = get_user_meta($current_user->ID);

$completed = 0;
$total     = 0;

$main_fields = [
    $current_user->first_name,
    $current_user->last_name,
    $current_user->display_name,
    $current_user->user_email
];
foreach ($main_fields as $value) {
    $total++;
    if (!empty($value)) $completed++;
}

$billing_fields = ['billing_first_name','billing_last_name','billing_address_1','billing_city','billing_postcode','billing_phone'];
foreach ($billing_fields as $field) {
    $total++;
    if (!empty($user_meta[$field][0])) $completed++;
}

$percent_complete = $total > 0 ? round(($completed / $total) * 100) : 0;

$registered   = strtotime($current_user->user_registered);
$now          = current_time('timestamp');
$days_member  = floor(($now - $registered) / DAY_IN_SECONDS);

$order_statuses = [
	'on-hold'    => 'در انتظار بررسی',
    'processing' => 'در حال آماده سازی',
    'completed'  => 'تکمیل شده',
    'cancelled'  => 'لغو شده'
];

$order_counts = [];
foreach ($order_statuses as $status => $label) {
    $order_counts[$status] = wc_get_orders([
        'customer_id' => $current_user->ID,
        'status'      => $status,
        'return'      => 'ids'
    ]);
}
?>
    <div class="zoominix-order-boxes">
    <div class="order-box">
        <!-- آیکون در انتظار بررسی -->
        <svg width="24" height="24" fill="#007bff" viewBox="0 0 24 24">
            <path d="M12 22a10 10 0 1110-10 10.011 10.011 0 01-10 10zm-1-17h2v6h-2zm0 8h2v2h-2z"/>
        </svg>
        <p>در انتظار بررسی: <?php echo count($order_counts['on-hold']); ?></p>
    </div>

    <div class="order-box">
        <!-- آیکون در حال آماده‌سازی -->
        <svg width="24" height="24" fill="#ff9800" viewBox="0 0 24 24">
            <path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 11h5v-2h-7V5h2v8z"/>
        </svg>
        <p>در حال آماده‌سازی: <?php echo count($order_counts['processing']); ?></p>
    </div>

    <div class="order-box">
        <!-- آیکون تکمیل شده -->
        <svg width="24" height="24" fill="#4caf50" viewBox="0 0 24 24">
            <path d="M9 16.17L4.83 12 3.41 13.41 9 19l12-12-1.41-1.41z"/>
        </svg>
        <p>تکمیل شده: <?php echo count($order_counts['completed']); ?></p>
    </div>

    <div class="order-box">
        <!-- آیکون لغو شده -->
        <svg width="24" height="24" fill="#f44336" viewBox="0 0 24 24">
            <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 
                     12-12S18.627 0 12 0zm5.707 16.293l-1.414 
                     1.414L12 13.414l-4.293 4.293-1.414-1.414L10.586 
                     12 6.293 7.707l1.414-1.414L12 10.586l4.293-4.293 
                     1.414 1.414L13.414 12l4.293 4.293z"/>
        </svg>
        <p>لغو شده: <?php echo count($order_counts['cancelled']); ?></p>
    </div>
</div>


<div class="zoominix-dashboard-card">

    <div class="zoominix-dashboard-avatar">
        <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo $display_name; ?>">
        <p class="name"><strong><?php echo $display_name; ?></strong></p>
    </div>
<div class="zoominix-profile-info"> 
	
	
    <div class="zoominix-profile-section">
        <h4>پیشرفت پروفایل</h4>
        <div class="progress-bar-wrapper">
            <div class="progress-bar-fill"></div>
            <div class="progress-marker"></div>
        </div>
    </div>

    <div class="zoominix-dashboard-info">
        <p><a href="<?php echo $logout_url; ?>">خروج از حساب</a></p>
        <p class="membership-info">
            سابقه عضویت: <?php echo $days_member; ?> روز
        </p>
    </div>
</div>

</div>

<script>window.profileFilled = <?php echo $percent_complete; ?>;</script>


<?php
$recent_orders = wc_get_orders([
    'customer_id' => $current_user->ID,
    'limit'       => 5,
    'orderby'     => 'date',
    'order'       => 'DESC'
]);
?>

<?php if ( ! empty( $recent_orders ) ) : ?>
    <div class="zoominix-recent-orders">
        <h4>آخرین سفارش‌</h4>
        <table class="zoominix-orders-table">
            <thead>
                <tr>
                    <th>شماره</th>
                    <th>تاریخ</th>
                    <th>مبلغ</th>
                    <th>وضعیت</th>
                    <th>جزئیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $recent_orders as $order ) : ?>
                    <tr>
                        <td>#<?php echo $order->get_id(); ?></td>
                        <td>
    <?php
    if (function_exists('jdate')) {
        echo jdate('Y/m/d', strtotime( $order->get_date_created() ));
    } else {
        echo date('Y/m/d', strtotime( $order->get_date_created() ));
    }
    ?>
</td>

                        <td><?php echo wc_price( $order->get_total() ); ?></td>
                        <td><?php echo wc_get_order_status_name( $order->get_status() ); ?></td>
                        <td><a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">مشاهده</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php
do_action('woocommerce_account_dashboard');
do_action('woocommerce_before_my_account');
do_action('woocommerce_after_my_account');
?>
