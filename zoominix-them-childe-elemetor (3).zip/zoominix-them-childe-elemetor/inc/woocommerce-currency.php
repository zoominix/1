<?php
/**
 * Ultra Improved WooCommerce Currency Manager
 * مدیریت پیشرفته نماد تومان در ووکامرس - نسخه بهبود یافته
 * 
 * @version 2.1.1
 * @author Manus AI
 * @description حل کامل مشکلات موقعیت نماد و FOUC
 */

// جلوگیری از دسترسی مستقیم
if (!defined('ABSPATH')) {
    exit;
}

class UltraImprovedWooCommerceCurrency {
    
    private $currency_position;
    private $svg_url;
    private $debug_mode;
    
    public function __construct() {
        $this->debug_mode = defined('WP_DEBUG') && WP_DEBUG;
        $this->init();
    }
    
    /**
     * راه‌اندازی اولیه
     */
    public function init() {
        // اضافه کردن ارز تومان گرافیکی
        add_filter('woocommerce_currencies', array($this, 'add_toman_currency'));
        add_filter('woocommerce_currency_symbol', array($this, 'add_toman_currency_symbol'), 10, 2);
        
        // تنظیم URL آیکن SVG
        $this->svg_url = get_stylesheet_directory_uri() . '/assets/icon/tooman.svg';
        
        // اضافه کردن اسکریپت‌ها و استایل‌ها
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // اضافه کردن متا تگ برای موقعیت ارز
        add_action('wp_head', array($this, 'add_currency_position_meta'), 1);
        
        // اضافه کردن CSS فوری برای جلوگیری از FOUC
        add_action('wp_head', array($this, 'add_immediate_fouc_prevention'), 2);
        
        // اضافه کردن تنظیمات JavaScript
        add_action('wp_head', array($this, 'add_currency_settings'), 3);
        
        // اضافه کردن AJAX handler برای دریافت موقعیت ارز
        add_action('wp_ajax_get_currency_position', array($this, 'ajax_get_currency_position'));
        add_action('wp_ajax_nopriv_get_currency_position', array($this, 'ajax_get_currency_position'));
        
        // اضافه کردن فیلتر برای بهبود نمایش در React components
        add_filter('woocommerce_get_price_html', array($this, 'improve_price_html'), 20, 2);
        
        // اضافه کردن پشتیبانی از Elementor
        add_action('elementor/frontend/after_enqueue_scripts', array($this, 'enqueue_elementor_scripts'));
        
        if ($this->debug_mode) {
            error_log('Ultra Improved WooCommerce Currency: راه‌اندازی شد');
        }
    }
    
    /**
     * اضافه کردن ارز تومان گرافیکی
     */
    public function add_toman_currency($currencies) {
        $currencies['toman_svg'] = __('تومان گرافیکی (SVG)', 'woocommerce');
        return $currencies;
    }
    
    /**
     * اضافه کردن نماد ارز تومان
     */
    public function add_toman_currency_symbol($currency_symbol, $currency) {
        if (is_admin()) return $currency_symbol;
        switch ($currency) {
            case 'toman_svg':
                $currency_symbol = '[TOMAN_ICON]';
                break;
        }
        return $currency_symbol;
    }
    
    /**
     * دریافت موقعیت ارز فعلی
     */
    private function get_currency_position() {
        if (!$this->currency_position) {
            $this->currency_position = get_option('woocommerce_currency_pos', 'left');
        }
        return $this->currency_position;
    }
    
    /**
     * اضافه کردن متا تگ برای موقعیت ارز
     */
    public function add_currency_position_meta() {
        $position = $this->get_currency_position();
        echo '<meta name="wc-currency-position" content="' . esc_attr($position) . '">' . "\n";
        
        if ($this->debug_mode) {
            echo '<!-- Ultra Currency Manager: موقعیت ارز = ' . esc_html($position) . ' -->' . "\n";
        }
    }
    
    /**
     * اضافه کردن CSS فوری برای جلوگیری از FOUC
     */
    public function add_immediate_fouc_prevention() {
        ?>
        <style id="ultra-immediate-fouc-prevention">
            /* جلوگیری فوری از FOUC - بالاترین اولویت */
            .woocommerce-Price-amount:not([data-currency-processed]) {
                visibility: hidden !important;
                position: relative !important;
            }
            
            .woocommerce-Price-amount:not([data-currency-processed])::before {
                content: '' !important;
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                right: 0 !important;
                bottom: 0 !important;
                background: linear-gradient(90deg, 
                    rgba(220,220,220,0.4) 25%, 
                    rgba(220,220,220,0.2) 37%, 
                    rgba(220,220,220,0.4) 63%) !important;
                background-size: 400% 100% !important;
                animation: ultra-shimmer 1.2s ease-in-out infinite !important;
                border-radius: 2px !important;
                visibility: visible !important;
                z-index: 1 !important;
            }
            
            @keyframes ultra-shimmer {
                0% { background-position: 100% 0; }
                100% { background-position: -100% 0; }
            }
            
            /* نمایش فوری پس از پردازش */
            .woocommerce-Price-amount[data-currency-processed] {
                visibility: visible !important;
                opacity: 1 !important;
            }
            
            .woocommerce-Price-amount[data-currency-processed]::before {
                display: none !important;
            }
            
            /* تنظیمات اولیه flexbox */
            .woocommerce-Price-amount {
                display: inline-flex !important;
                align-items: center !important;
                gap: 2px !important;
            }
            
            /* آیکن تومان */
            .custom-currency-icon {
                display: inline-block !important;
                width: 1em !important;
                height: 1em !important;
                background-image: url('<?php echo esc_url($this->svg_url); ?>') !important;
                background-size: contain !important;
                background-repeat: no-repeat !important;
                background-position: center !important;
                vertical-align: middle !important;
                flex-shrink: 0 !important;
            }
        </style>
        <?php
    }
    
    /**
     * اضافه کردن تنظیمات JavaScript
     */
    public function add_currency_settings() {
        $position = $this->get_currency_position();
        ?>
        <script>
            window.currencySettings = {
                currency_pos: '<?php echo esc_js($position); ?>',
                svg_url: '<?php echo esc_js($this->svg_url); ?>',
                debug: <?php echo $this->debug_mode ? 'true' : 'false'; ?>,
                token: '[TOMAN_ICON]'
            };
            
            <?php if ($this->debug_mode): ?>
            console.log('🔧 Currency Settings:', window.currencySettings);
            <?php endif; ?>
        </script>
        <?php
    }
    
    /**
     * اضافه کردن اسکریپت‌ها
     */
    public function enqueue_scripts() {
        // اسکریپت اصلی
        wp_enqueue_script(
            'ultra-advanced-currency-manager',
            get_stylesheet_directory_uri() . '/assets/js/currency-position-fix.js',
            array('jquery'),
            '2.1.1',
            false // در head بارگذاری شود
        );
        
        // CSS اضافی
        wp_add_inline_style('woocommerce-general', $this->get_additional_css());
        
        if ($this->debug_mode) {
            error_log('Ultra Currency Manager: اسکریپت‌ها بارگذاری شدند');
        }
    }
    
    /**
     * اضافه کردن اسکریپت‌های Elementor
     */
    public function enqueue_elementor_scripts() {
        if (did_action('elementor/loaded')) {
            wp_enqueue_script(
                'ultra-currency-elementor',
                get_stylesheet_directory_uri() . '/assets/js/currency-position-fix.js',
                array('jquery', 'elementor-frontend'),
                '2.1.1',
                false
            );
        }
    }
    
    /**
     * CSS اضافی
     */
    private function get_additional_css() {
        $position = $this->get_currency_position();
        $flex_direction = (strpos($position, 'left') !== false) ? 'row' : 'row-reverse';
        $gap = (strpos($position, '_space') !== false) ? '4px' : '2px';
        
        return "
            /* تنظیمات پیشرفته موقعیت ارز */
            :root {
                --ultra-currency-flex-direction: {$flex_direction};
                --ultra-currency-gap: {$gap};
                --ultra-currency-position: {$position};
            }
            
            /* اولویت بالا برای flexbox */
            .ultra-currency-manager-active .woocommerce-Price-amount {
                flex-direction: var(--ultra-currency-flex-direction, row-reverse) !important;
                gap: var(--ultra-currency-gap, 2px) !important;
            }
            
            /* تنظیمات ویژه برای React components */
            .wc-block-cart .woocommerce-Price-amount,
            .wc-block-checkout .woocommerce-Price-amount,
            .wc-block-formatted-money-amount {
                flex-direction: var(--ultra-currency-flex-direction, row-reverse) !important;
                display: inline-flex !important;
                align-items: center !important;
                gap: var(--ultra-currency-gap, 2px) !important;
            }
            
            /* تنظیمات ویژه برای Elementor */
            .elementor-widget-woocommerce-product-price .woocommerce-Price-amount,
            .elementor-widget-woocommerce-menu-cart .woocommerce-Price-amount {
                flex-direction: var(--ultra-currency-flex-direction, row-reverse) !important;
            }
            
            /* حل مشکل تداخل با سایر CSS ها */
            .custom-currency-icon {
                order: " . ((strpos($position, 'left') !== false) ? '-1' : '1') . " !important;
            }
            
            /* بهبود نمایش در موبایل */
            @media (max-width: 768px) {
                .woocommerce-Price-amount {
                    font-size: inherit !important;
                }
                
                .custom-currency-icon {
                    width: 0.9em !important;
                    height: 0.9em !important;
                }
            }
        ";
    }
    
    /**
     * بهبود HTML قیمت
     */
    public function improve_price_html($price, $product) {
        // اگر قیمت شامل توکن تومان است، کلاس‌های مناسب اضافه کن
        if (strpos($price, '[TOMAN_ICON]') !== false) {
            $price = str_replace(
                'class="woocommerce-Price-amount',
                'class="woocommerce-Price-amount currency-needs-processing',
                $price
            );
        }
        
        return $price;
    }
    
    /**
     * AJAX handler برای دریافت موقعیت ارز
     */
    public function ajax_get_currency_position() {
        // بررسی nonce برای امنیت
        if (!wp_verify_nonce($_POST['nonce'], 'wc_currency_nonce')) {
            wp_die('Security check failed');
        }
        
        $position = $this->get_currency_position();
        
        wp_send_json_success(array(
            'currency_pos' => $position,
            'svg_url' => $this->svg_url,
            'debug' => $this->debug_mode
        ));
    }
    
    /**
     * اضافه کردن نماد تومان به فهرست ارزها در تنظیمات
     */
    public function add_toman_to_currency_list() {
        add_filter('woocommerce_get_currency_symbol', function($symbol, $currency) {
            if ($currency === 'toman_svg') {
                return '<span class="custom-currency-icon" aria-label="تومان"></span>';
            }
            return $symbol;
        }, 10, 2);
    }
    
    /**
     * اضافه کردن پشتیبانی از WooCommerce Blocks
     */
    public function add_blocks_support() {
        add_action('enqueue_block_assets', function() {
            wp_enqueue_script(
                'ultra-currency-blocks',
                get_stylesheet_directory_uri() . '/assets/js/currency-position-fix.js',
                array('wp-blocks', 'wp-element'),
                '2.1.0',
                false
            );
        });
    }
    
    /**
     * Debug helper
     */
    public function debug_log($message) {
        if ($this->debug_mode) {
            error_log('Ultra Currency Manager: ' . $message);
        }
    }
    
    /**
     * بررسی سازگاری
     */
    public function check_compatibility() {
        $issues = array();
        
        // بررسی وجود WooCommerce
        if (!class_exists('WooCommerce')) {
            $issues[] = 'WooCommerce پلاگین نصب نیست';
        }
        
        // بررسی وجود فایل SVG
        $svg_path = get_stylesheet_directory() . '/assets/icon/tooman.svg';
        if (!file_exists($svg_path)) {
            $issues[] = 'فایل SVG آیکن تومان یافت نشد: ' . $svg_path;
        }
        
        // بررسی وجود فایل JavaScript
        $js_path = get_stylesheet_directory() . '/assets/js/currency-position-fix.js';
        if (!file_exists($js_path)) {
            $issues[] = 'فایل JavaScript یافت نشد: ' . $js_path;
        }
        
        if (!empty($issues) && $this->debug_mode) {
            foreach ($issues as $issue) {
                error_log('Ultra Currency Manager Warning: ' . $issue);
            }
        }
        
        return empty($issues);
    }
    
    /**
     * نصب و راه‌اندازی
     */
    public static function install() {
        // ایجاد پوشه‌های مورد نیاز
        $upload_dir = wp_upload_dir();
        $currency_dir = $upload_dir['basedir'] . '/currency-manager/';
        
        if (!file_exists($currency_dir)) {
            wp_mkdir_p($currency_dir);
        }
        
        // تنظیم پیش‌فرض ارز به تومان گرافیکی
        if (get_option('woocommerce_currency') === false) {
            update_option('woocommerce_currency', 'toman_svg');
        }
        
        // تنظیم پیش‌فرض موقعیت ارز
        if (get_option('woocommerce_currency_pos') === false) {
            update_option('woocommerce_currency_pos', 'right');
        }
    }
    
    /**
     * حذف
     */
    public static function uninstall() {
        // پاک‌سازی تنظیمات (اختیاری)
        // delete_option('woocommerce_currency');
        // delete_option('woocommerce_currency_pos');
    }
}

// راه‌اندازی کلاس
new UltraImprovedWooCommerceCurrency();

// Hook های نصب و حذف
register_activation_hook(__FILE__, array('UltraImprovedWooCommerceCurrency', 'install'));
register_deactivation_hook(__FILE__, array('UltraImprovedWooCommerceCurrency', 'uninstall'));

// اضافه کردن action برای بررسی سازگاری
add_action('admin_notices', function() {
    $currency_manager = new UltraImprovedWooCommerceCurrency();
    if (!$currency_manager->check_compatibility()) {
        echo '<div class="notice notice-warning"><p><strong>Ultra Currency Manager:</strong> برخی مشکلات سازگاری شناسایی شد. لطفاً لاگ‌های خطا را بررسی کنید.</p></div>';
    }
});

// اضافه کردن منوی تنظیمات در admin (اختیاری)
add_action('admin_menu', function() {
    add_submenu_page(
        'woocommerce',
        'تنظیمات نماد تومان',
        'نماد تومان',
        'manage_woocommerce',
        'ultra-currency-settings',
        function() {
            ?>
            <div class="wrap">
                <h1>تنظیمات نماد تومان</h1>
                <div class="notice notice-info">
                    <p><strong>راهنما:</strong> برای استفاده از نماد تومان گرافیکی، در تنظیمات WooCommerce > عمومی، ارز را به "تومان گرافیکی (SVG)" تغییر دهید.</p>
                </div>
                
                <h2>وضعیت سیستم</h2>
                <table class="widefat">
                    <tr>
                        <td><strong>ارز فعلی:</strong></td>
                        <td><?php echo get_woocommerce_currency(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>موقعیت ارز:</strong></td>
                        <td><?php echo get_option('woocommerce_currency_pos', 'right'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>فایل SVG:</strong></td>
                        <td><?php echo file_exists(get_stylesheet_directory() . '/assets/icon/tooman.svg') ? '✅ موجود' : '❌ یافت نشد'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>فایل JavaScript:</strong></td>
                        <td><?php echo file_exists(get_stylesheet_directory() . '/assets/js/currency-position-fix.js') ? '✅ موجود' : '❌ یافت نشد'; ?></td>
                    </tr>
                </table>
                
                <h2>ابزارهای Debug</h2>
                <p>برای debug، در Console مرورگر دستورات زیر را اجرا کنید:</p>
                <ul>
                    <li><code>currencyDebug()</code> - نمایش اطلاعات debug</li>
                    <li><code>enableCurrencyDebug()</code> - فعال‌سازی حالت debug</li>
                    <li><code>forceReprocessCurrency()</code> - اجبار پردازش مجدد</li>
                </ul>
            </div>
            <?php
        }
    );
});

?>

