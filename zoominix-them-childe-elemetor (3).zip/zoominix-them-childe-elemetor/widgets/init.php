<?php
/**
 * Elementor Widgets Initialization
 *
 * @package Zoominix\Elementor
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Register and initialize all Elementor widgets
 */
function zoominix_register_elementor_widgets() {
    // Register Slide Menu Widget
    require_once get_stylesheet_directory() . '/widgets/Slide_Menu_Widget.php';
}
add_action( 'elementor/init', 'zoominix_register_elementor_widgets' );

/**
 * Register widget assets (CSS and JS files)
 */
function zoominix_register_elementor_widget_assets() {
    // Register Slide Menu Widget assets
    wp_register_style(
        'zoominix-slide-menu-style',
        get_stylesheet_directory_uri() . '/widgets/assets/slide-menu.css',
        [],
        '1.0.0'
    );
    
    wp_register_script(
        'zoominix-slide-menu-script',
        get_stylesheet_directory_uri() . '/widgets/assets/slide-menu.js',
        ['jquery'],
        '1.0.0',
        true
    );
}
add_action( 'wp_enqueue_scripts', 'zoominix_register_elementor_widget_assets' );
