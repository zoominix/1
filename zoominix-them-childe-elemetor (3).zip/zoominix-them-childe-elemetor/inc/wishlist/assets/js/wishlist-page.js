document.addEventListener('DOMContentLoaded', () => {
  const storageKey = 'zoominix_wishlist';
  const isLoggedIn = document.body.classList.contains('logged-in');
  const container = document.getElementById('zoominix-guest-wishlist');
  let debounceTimer;

  if (!container) return;

  function showToast(message) {
    const toast = document.getElementById('wishlist-toast');
    if (!toast) return;
    toast.textContent = message;
    toast.style.display = 'block';
    setTimeout(() => {
      toast.style.display = 'none';
    }, 2000);
  }

  function getWishlist() {
    try {
      const raw = localStorage.getItem(storageKey);
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed?.items) ? parsed.items : [];
    } catch {
      return [];
    }
  }

  function saveWishlist(items) {
    const data = {
      items,
      timestamp: new Date().getTime()
    };
    localStorage.setItem(storageKey, JSON.stringify(data));

    // ذخیره در متای کاربر (اگر وارد شده باشد)
    if (isLoggedIn && typeof zoominixWishlist !== 'undefined') {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        fetch(zoominixWishlist.ajaxurl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            action: 'zoominix_sync_wishlist',
            nonce: zoominixWishlist.nonce,
            wishlist: JSON.stringify(items)
          })
        });
      }, 3000);
    }
  }

  function removeItem(productId) {
    let list = getWishlist().filter(id => id !== productId);
    saveWishlist(list);

    if (isLoggedIn && typeof zoominixWishlist !== 'undefined') {
      fetch(zoominixWishlist.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'zoominix_remove_from_wishlist',
          nonce: zoominixWishlist.nonce,
          product_id: productId
        })
      });
    }

    // حذف DOM
    const item = container.querySelector(`[data-product-id="${productId}"]`);
    if (item) item.remove();

    // حذف قلب در صفحه محصول (در صورت وجود)
    document.querySelectorAll(`.zoominix-wishlist-btn[data-product-id="${productId}"]`)
      .forEach(btn => btn.classList.remove('filled'));

    // نمایش پیام خالی
    if (!container.querySelector('.wishlist-item')) {
      container.innerHTML = '<p>لیست علاقه‌مندی‌های شما خالی است.</p>';
    }

    showToast('❌ از علاقه‌مندی‌ها حذف شد');
  }

  function renderItems(products) {
    if (!products.length) {
      container.innerHTML = '<p>لیست علاقه‌مندی‌های شما خالی است.</p>';
      return;
    }

    let html = '<div class="zoominix-wishlist-grid">';
    products.forEach(product => {
      html += `
        <div class="wishlist-item" data-product-id="${product.id}">
          <a href="${product.permalink}">
            <img src="${product.image}" alt="${product.name}" />
            <h3>${product.name}</h3>
            <span>${product.price_html}</span>
          </a>
          <button class="remove-from-wishlist" aria-label="حذف از علاقه‌مندی‌ها">
            <i class="fa-regular fa-trash"></i>
          </button>
        </div>`;
    });
    html += '</div>';
    container.innerHTML = html;
  }

  function fetchProducts(ids) {
    if (!ids.length) {
      container.innerHTML = '<p>لیست علاقه‌مندی‌های شما خالی است.</p>';
      return;
    }

    fetch(`/wp-json/wc/store/products?include=${ids.join(',')}`)
      .then(res => res.json())
      .then(data => {
        const products = data.map(p => ({
          id: p.id,
          name: p.name,
          permalink: p.permalink,
          image: p.images[0]?.src || '',
          price_html: p.price_html
        }));
        renderItems(products);
      });
  }

  function loadWishlist() {
    if (isLoggedIn && getWishlist().length === 0) {
      fetch(zoominixWishlist.ajaxurl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          action: 'zoominix_get_wishlist',
          nonce: zoominixWishlist.nonce
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.wishlist)) {
          saveWishlist(data.wishlist);
          fetchProducts(data.wishlist);
        } else {
          container.innerHTML = '<p>لیست علاقه‌مندی‌های شما خالی است.</p>';
        }
      });
    } else {
      const list = getWishlist();
      fetchProducts(list);
    }
  }

  // دکمه حذف
  document.addEventListener('click', e => {
    const btn = e.target.closest('.remove-from-wishlist');
    if (!btn) return;
    const item = btn.closest('.wishlist-item');
    const productId = parseInt(item?.dataset.productId);
    if (!productId) return;
    removeItem(productId);
  });

  loadWishlist();
});
