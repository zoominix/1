document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.custom-quantity-wrapper').forEach(function (wrapper) {
    const input = wrapper.querySelector('input.qty');
    const plus = wrapper.querySelector('.plus');
    const minus = wrapper.querySelector('.minus');

    plus.addEventListener('click', function () {
      let current = parseInt(input.value) || 0;
      input.value = current + 1;
      input.dispatchEvent(new Event('change'));
    });

    minus.addEventListener('click', function () {
      let current = parseInt(input.value) || 0;
      if (current > 1) {
        input.value = current - 1;
        input.dispatchEvent(new Event('change'));
      }
    });
  });

  const shareBtn = document.querySelector('#share-button');
  if (shareBtn && navigator.share) {
    shareBtn.addEventListener('click', function (e) {
      e.preventDefault();
      navigator.share({
        title: document.title,
        url: window.location.href
      }).catch(console.error);
    });
  }

  const attributeBtn = document.querySelector('.button-attributee');
  if (attributeBtn) {
    attributeBtn.addEventListener('click', function () {
      const tabLink = document.querySelector('#tab-title-additional_information a');
      const tabContent = document.querySelector('#tab-additional_information');

      if (tabLink && tabContent) {
        tabLink.click();

        setTimeout(function () {
          const offset = 300;
          const elementTop = tabLink.getBoundingClientRect().top + window.pageYOffset;
          window.scrollTo({
            top: elementTop - offset,
            behavior: 'smooth'
          });
        }, 200);
      }
    });
  }
});
