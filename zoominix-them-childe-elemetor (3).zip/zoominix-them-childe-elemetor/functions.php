<?php
function hello_elementor_child_enqueue_styles() {
    wp_enqueue_style('hello-elementor-style', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('hello-elementor-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array('hello-elementor-style'),
        wp_get_theme()->get('Version')
    );
}
add_action('wp_enqueue_scripts', 'hello_elementor_child_enqueue_styles');

require_once get_stylesheet_directory() . '/widgets/init.php';
require_once get_stylesheet_directory() . '/inc/woocommerce-currency.php';

require_once get_stylesheet_directory() . '/inc/wishlist/init.php';

require_once get_stylesheet_directory() . '/inc/woocommerce-hooks.php';

require_once get_stylesheet_directory() . '/inc/attribute/shortcodes.php';

require_once get_stylesheet_directory() . '/inc/enqueue.php';
require_once get_stylesheet_directory() . '/inc/myaccount-orders/ajax.php';

// require_once get_stylesheet_directory() . '/inc/category/shortcodes.php';


